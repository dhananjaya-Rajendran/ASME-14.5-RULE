"""Conservative dimension parsing from individual PDF/OCR text blocks."""
import re
from typing import Any

from gdt_validator.schemas import DimensionItem
from gdt_validator.models.drawing_ir import DrawingTolerance, Evidence

NUMBER = r"\d+(?:[.,]\d+)?"
DIAMETER = r"(?:\u00d8|\u2300|\u2205|DIA\s*)"
MULTIPLY = r"(?:x|\u00d7)"


def extract_dimensions(text_blocks: list[dict[str, Any]], page: int = 1,
                       unit: str | None = None) -> tuple[list[DimensionItem], list[DrawingTolerance]]:
    dimensions, tolerances = [], []
    for index, block in enumerate(text_blocks):
        raw = str(block.get("text", "")).strip()
        normalized = raw.replace("\u00a0", " ").replace(",", ".").strip()
        if not normalized or _is_general_tolerance(normalized):
            continue
        parsed = _parse_dimension(normalized)
        if parsed is None:
            continue
        nominal, kind, tol_type, upper, lower, basic, reference = parsed
        bbox = list(block.get("bbox") or [0.0, 0.0, 0.0, 0.0])
        confidence = float(block.get("confidence", 0.78 if block.get("source") == "ocr" else 0.82))
        confidence = min(1.0, max(0.0, confidence))
        dim_id = f"dim_p{page}_{index:04d}"
        dimensions.append(DimensionItem(
            id=dim_id, bbox=bbox, nominal=nominal, upper_tol=upper, lower_tol=lower,
            has_tolerance=tol_type not in {"NONE", "UNKNOWN"}, is_basic=basic,
            is_reference=reference, page=page, confidence=confidence,
            source="ocr" if block.get("source") == "ocr" else "pdf_text",
            source_text=raw, dimension_type=kind, unit=unit, tolerance_type=tol_type))
        if tol_type in {"BILATERAL", "UNILATERAL", "LIMITS"}:
            tolerances.append(DrawingTolerance(
                id=f"tol_{dim_id}", dimension_id=dim_id, type=tol_type,
                upper=upper, lower=lower, source_text=raw,
                evidence=Evidence(source="ocr" if block.get("source") == "ocr" else "pdf_text",
                                 page=page, bbox=bbox, source_text=raw,
                                 confidence=confidence)))
    return dimensions, tolerances


def _is_general_tolerance(text: str) -> bool:
    return bool(re.search(r"(?i)ISO\s*2768|UNLESS OTHERWISE SPECIFIED|GENERAL TOLERANCES?", text))


def _parse_dimension(text: str):
    s = text.strip()
    basic = s.startswith(("\u25a1", "\u25b1", "\u2316"))
    if basic:
        s = s[1:].strip()
    reference = s.startswith("(") and s.endswith(")")
    if reference:
        s = s[1:-1].strip()

    thread = re.search(rf"(?i)\bM\s*({NUMBER})(?:\s*{MULTIPLY}\s*({NUMBER}))?", s)
    if thread:
        return float(thread.group(1)), "THREAD", "UNKNOWN", 0.0, 0.0, basic, reference
    chamfer = re.search(rf"(?i)(?:C\s*)?({NUMBER})\s*{MULTIPLY}\s*({NUMBER})\s*\u00b0", s)
    if chamfer:
        return float(chamfer.group(1)), "CHAMFER", "NONE", 0.0, 0.0, basic, reference
    angle = re.search(rf"({NUMBER})\s*\u00b0", s)
    if angle:
        val = float(angle.group(1))
        return val, "ANGULAR", *_parse_tolerance(s, val), basic, reference
    depth = re.search(rf"(?i)(?:DEPTH|DEEP)\s*({NUMBER})", s)
    if depth:
        return float(depth.group(1)), "DEPTH", "NONE", 0.0, 0.0, basic, reference
    dia = re.search(rf"(?i){DIAMETER}\s*({NUMBER})", s)
    if dia:
        val = float(dia.group(1))
        return val, "DIAMETER", *_parse_tolerance(s, val), basic, reference
    radius = re.search(rf"(?i)\bR\s*({NUMBER})", s)
    if radius:
        val = float(radius.group(1))
        return val, "RADIUS", *_parse_tolerance(s, val), basic, reference
    plain = re.fullmatch(rf"\s*({NUMBER})\s*", s)
    if plain:
        return float(plain.group(1)), "LINEAR", "NONE", 0.0, 0.0, basic, reference
    value = re.search(NUMBER, s)
    if value and ("\u00b1" in s or "+/-" in s or re.search(rf"{NUMBER}\s*/\s*[-\u2212+]?{NUMBER}", s)):
        val = float(value.group())
        return val, "LINEAR", *_parse_tolerance(s, val), basic, reference
    return None


def _parse_tolerance(text: str, nominal: float):
    bilateral = re.search(rf"(?:\u00b1|\+/-)\s*({NUMBER})", text)
    if bilateral:
        amount = float(bilateral.group(1))
        return "BILATERAL", amount, -amount
    unilateral = re.search(rf"\+\s*({NUMBER})\s*/\s*[-\u2212]\s*({NUMBER})", text)
    if unilateral:
        return "UNILATERAL", float(unilateral.group(1)), -float(unilateral.group(2))
    limit_values = re.findall(NUMBER, text)
    if len(limit_values) >= 2 and re.search(r"(?i)LIMIT|MAX|MIN", text):
        values = [float(value) for value in limit_values[:2]]
        return "LIMITS", max(values) - nominal, min(values) - nominal
    return "NONE", 0.0, 0.0
