import re
from typing import Dict, List

import pymupdf as fitz


class LeaderLineTracer:
    """Small text-assisted feature association helper; uncertain links stay unknown."""

    DIAMETER_REGEX = re.compile(r"(Ø|\bDIA\b|\bDIAM\b|\bR\s*\d)", re.IGNORECASE)
    TOLERANCE_REGEX = re.compile(r"(±|\+\s*\d|\-\s*\d|\d+\.\d+\s*/\s*\d+\.\d+)")

    def __init__(self, snap_tol_pt: float = 3.5, tip_radius_pt: float = 9.0):
        self.snap_tol_pt = snap_tol_pt
        self.tip_radius_pt = tip_radius_pt

    def trace_fcf_target(self, pdf_path: str, fcf_bbox: List[float],
                         page_num: int = 0) -> Dict:
        with fitz.open(pdf_path) as doc:
            page = doc[page_num]
            fcf_rect = fitz.Rect(fcf_bbox)
            above_rect = fitz.Rect(max(0, fcf_rect.x0 - 12),
                                   max(0, fcf_rect.y0 - 35),
                                   min(page.rect.width, fcf_rect.x1 + 12),
                                   max(0, fcf_rect.y0 + 2))
            above_text = page.get_text("text", clip=above_rect).strip()
        if above_text and self.DIAMETER_REGEX.search(above_text):
            return {"associated_feature_type": "hole",
                    "has_size_tolerance_on_feature": bool(self.TOLERANCE_REGEX.search(above_text)),
                    "trace_method": "stacked_diameter"}
        return {"associated_feature_type": "unknown",
                "has_size_tolerance_on_feature": None,
                "trace_method": "unresolved"}
