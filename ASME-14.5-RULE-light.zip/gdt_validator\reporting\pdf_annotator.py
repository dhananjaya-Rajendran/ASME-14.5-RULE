from pathlib import Path
from typing import List

import pymupdf as fitz

from gdt_validator.schemas import ValidationViolation


def annotate_drawing_pdf(input_pdf: str, output_pdf: str,
                         violations: List[ValidationViolation], page_num: int = 0) -> str:
    output = Path(output_pdf)
    output.parent.mkdir(parents=True, exist_ok=True)
    with fitz.open(input_pdf) as doc:
        page = doc[page_num]
        for violation in violations:
            rect = fitz.Rect(violation.bbox)
            color = (1, 0, 0) if violation.severity == "ERROR" else (1, 0.55, 0)
            page.draw_rect(rect, color=color, width=2.0)
            annot = page.add_text_annot(
                rect.tl, f"[{violation.rule_id}] {violation.description}")
            annot.set_colors(stroke=color)
            annot.update()
        doc.save(str(output), garbage=4, deflate=True)
    return str(output)
