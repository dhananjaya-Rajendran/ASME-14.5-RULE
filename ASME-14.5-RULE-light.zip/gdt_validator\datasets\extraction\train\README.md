Training split reserved for authorized, human-reviewed extraction labels. No drawings are currently included.
