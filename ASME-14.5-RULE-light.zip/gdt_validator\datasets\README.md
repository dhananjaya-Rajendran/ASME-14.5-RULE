# Benchmark data policy

Extraction and rule-validation evaluation are separate. Mock-mode tests only test software behavior and never count as model performance. Only drawings and labels marked `EXPERT_VERIFIED` may be used for benchmark metrics. Do not use LLM output as ground truth. Keep drawings and title-block data private unless authorized for release.

Expected structure:

```text
datasets/extraction/{train,validation,test}/
datasets/golden/extraction/benchmark.jsonl
datasets/golden/validation/benchmark.jsonl
```

The directories currently contain templates and instructions only. No approved drawing images or gold labels were supplied, so benchmark metrics are intentionally not reported.
