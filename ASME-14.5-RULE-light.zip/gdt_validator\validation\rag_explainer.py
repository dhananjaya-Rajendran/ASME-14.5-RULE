"""Post-decision reference retrieval; this module cannot create or alter outcomes."""
import logging
from typing import Iterable

from gdt_validator.knowledge_base import (
    CHROMA_COLLECTION_NAME, DEFAULT_CHROMA_PATH, DEFAULT_KB_PATH,
    _chroma_embedding_function, knowledge_base_info, retrieve_context,
)
from gdt_validator.schemas import RuleDecision, RuleExplanation, ReferenceCitation

logger = logging.getLogger(__name__)

RULE_GUIDANCE = {
    "ASME-Y14.5-DIM-001": "Check for a direct tolerance, a general tolerance note, or an applicable exception such as a basic or reference dimension.",
    "ASME-Y14.5-FORM-001": "Review the FCF and intended characteristic; verify datum references against the applicable standard and design intent.",
    "ASME-Y14.5-DATUM-002": "Inspect the drawing for the datum feature symbol. OCR can miss it; verify visually before changing the drawing.",
    "ASME-Y14.5-MOD-003": "Confirm the controlled geometry is a feature of size and that the modifier is attached to the intended control.",
    "ASME-Y14.5-MOD-004": "Verify the associated feature has stated size limits and that the material condition is evaluated against them.",
    "ASME-Y14.5-MOD-005": "Review the associated geometry in CAD or on the drawing to determine whether it is a feature of size.",
}


class ASMERagExplainer:
    """Return separate explanation records for frozen deterministic rule decisions."""

    def __init__(self, persist_dir: str = str(DEFAULT_CHROMA_PATH), use_chroma: bool = True,
                 knowledge_base_path: str = str(DEFAULT_KB_PATH)):
        self.collection = None
        self.knowledge_base_path = knowledge_base_path
        if use_chroma:
            try:
                import chromadb
                client = chromadb.PersistentClient(path=persist_dir)
                info = knowledge_base_info(knowledge_base_path)
                collection = client.get_collection(CHROMA_COLLECTION_NAME,
                    embedding_function=_chroma_embedding_function())
                if info and collection.metadata.get("edition") == info.get("edition"):
                    self.collection = collection
            except (ImportError, RuntimeError, ValueError, OSError) as exc:
                logger.warning("Chroma reference index unavailable; FTS fallback remains available: %s", exc)
                self.collection = None
            except Exception as exc:
                # Backend-specific index errors are non-fatal to deterministic validation.
                logger.warning("Chroma reference index could not be opened; using archive fallback: %s", exc)
                self.collection = None

    def explain(self, decisions: Iterable[RuleDecision]) -> list[RuleExplanation]:
        info = knowledge_base_info(self.knowledge_base_path)
        output = []
        for decision in decisions:
            # Enforce edition matching. An unknown/mismatched edition gets no citation.
            if not info or info.get("edition") != decision.edition:
                output.append(RuleExplanation(rule_id=decision.rule_id,
                    explanation_status="INSUFFICIENT_REFERENCE_EVIDENCE",
                    explanation="INSUFFICIENT_REFERENCE_EVIDENCE"))
                continue
            reference_tokens = decision.message
            query = " ".join(filter(None, [decision.standard, decision.edition,
                decision.rule_id, decision.reference_hint, reference_tokens]))
            passages = retrieve_context(query, self.knowledge_base_path, limit=4,
                max_chars=5000, collection=self.collection, expected_edition=decision.edition)
            citations = []
            for passage in passages:
                section = passage.get("section")
                if not section or section not in query:
                    # The source archive may not expose a clause. Never invent one.
                    continue
                distance = passage.get("distance")
                relevance = max(0.0, min(1.0, 1.0 - float(distance))) if isinstance(distance, (int, float)) else None
                citations.append(ReferenceCitation(
                    standard=decision.standard, edition=decision.edition,
                    section=str(section), source_id=f"{info.get('source_name', 'knowledge-base')}:p{passage.get('page')}",
                    page=passage.get("page"), relevance_score=relevance,
                    excerpt=str(passage.get("text", ""))))
            guidance = RULE_GUIDANCE.get(decision.rule_id)
            if citations:
                explanation = (f"Deterministic rule {decision.rule_id} returned {decision.status}: "
                               f"{decision.message} Retrieved excerpts are supporting reference evidence only.")
                status = "GROUNDED"
            else:
                explanation = "INSUFFICIENT_REFERENCE_EVIDENCE"
                status = "INSUFFICIENT_REFERENCE_EVIDENCE"
            output.append(RuleExplanation(rule_id=decision.rule_id,
                explanation_status=status, explanation=explanation,
                citations=citations, recommended_review=guidance))
        return output
