"""Evaluation utilities for measured VLM extraction quality."""
