"""Versioned registry for deterministic rules and their review state.

No current check is represented as expert verified: that designation needs an
independent engineering review against the licensed applicable standard.
"""
from dataclasses import dataclass
from typing import Literal
from gdt_validator.standards import PROJECT_STANDARD

VerificationStatus = Literal["DRAFT", "UNDER_REVIEW", "EXPERT_VERIFIED", "DEPRECATED"]


@dataclass(frozen=True)
class RuleMetadata:
    rule_id: str
    name: str
    standard: str
    edition: str
    category: str
    verification_status: VerificationStatus
    description: str


_RULES = [
    ("DIM-001", "Dimension tolerance completeness", "Warn when an explicit dimension has no parsed tolerance or recognized exception."),
    ("FCF-001", "FCF tolerance completeness", "Request review when the tolerance value is absent or non-positive."),
    ("FCF-002", "FCF characteristic support", "Request review for unknown or unsupported characteristics."),
    ("FORM-001", "Form control datum references", "Flag extracted datum references on form controls."),
    ("DATUM-001", "Required datum references", "Request review when a control typically requiring datum references has none extracted."),
    ("DATUM-002", "Declared datum presence", "Request review when a referenced datum is not in extracted declarations."),
    ("DATUM-003", "Duplicate datum reference", "Check for repeated datum letters in one extracted frame."),
    ("DATUM-004", "Datum reference count", "Check that no more than three datum references were extracted."),
    ("ZONE-001", "Form control zone modifier", "Flag a diameter zone modifier on a form control."),
    ("MOD-001", "Material modifier on form control", "Flag MMC/LMC on a form control."),
    ("MOD-003", "Feature of size applicability", "Check extracted MMC/LMC feature classification."),
    ("MOD-004", "Size tolerance linkage", "Warn when no size tolerance is linked to the feature."),
    ("MOD-005", "Feature of size classification", "Request review when modifier applicability cannot be determined."),
]

RULE_REGISTRY = {
    f"ASME-Y14.5-{suffix}": RuleMetadata(
        rule_id=f"ASME-Y14.5-{suffix}", name=name, standard=PROJECT_STANDARD.family,
        edition=PROJECT_STANDARD.edition, category=suffix.split("-")[0],
        verification_status="UNDER_REVIEW", description=description)
    for suffix, name, description in _RULES
}
