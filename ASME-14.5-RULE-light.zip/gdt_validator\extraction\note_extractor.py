"""Extract explicit note, general-tolerance, material, and finish annotations."""
import re

from gdt_validator.schemas import DrawingNote
from gdt_validator.models.drawing_ir import (Evidence, GeneralTolerance, MaterialInfo,
                                             SurfaceFinish)


def extract_notes(text_blocks: list[dict], page: int = 1):
    notes, general, materials, finishes = [], [], [], []
    for index, block in enumerate(text_blocks):
        text = re.sub(r"\s+", " ", str(block.get("text", "")).strip())
        if len(text) < 3:
            continue
        upper = text.upper()
        bbox = list(block.get("bbox") or [0, 0, 0, 0])
        confidence = float(block.get("confidence", 0.8))
        evidence = Evidence(source="ocr" if block.get("source") == "ocr" else "pdf_text",
                            page=page, bbox=bbox, source_text=text, confidence=confidence)
        is_general = bool(re.search(r"ISO\s*2768|GENERAL TOLERANCE|UNLESS OTHERWISE SPECIFIED", upper)
                          or re.fullmatch(r"\s*\u00b1\s*\d+(?:\.\d+)?\s*", text))
        if is_general:
            general.append(GeneralTolerance(id=f"gtol_p{page}_{index:04d}",
                specification=next(iter(re.findall(r"(?i)ISO\s*2768(?:-[A-Z]+)?", text)), None),
                source="TITLE_BLOCK" if index >= max(0, len(text_blocks) - 12) else "NOTE",
                raw_text=text, evidence=evidence))
            kind = "general_tolerance"
        elif re.search(r"(?i)MATERIAL\s*[:=]|ALUMINIUM|ALUMINUM|STAINLESS STEEL|AISI\s*\d", text):
            materials.append(MaterialInfo(material=text, evidence=[evidence]))
            kind = "material"
        elif re.search(r"(?i)Ra\s*\d+(?:\.\d+)?", text):
            match = re.search(r"(?i)Ra\s*(\d+(?:\.\d+)?)", text)
            finishes.append(SurfaceFinish(id=f"sf_p{page}_{index:04d}",
                roughness=float(match.group(1)), unit="um", parameter="Ra", evidence=evidence))
            kind = "surface_finish"
        elif re.search(r"(?i)BURR|SHARP EDGE|HEAT TREAT|COAT|PLAT|WELD|MACHINE", text):
            kind = "process"
        else:
            kind = "other"
        if kind == "other":
            tokens = re.findall(r"[A-Za-z]{2,}", text)
            if not (len(tokens) >= 3 and len(text) >= 18 and
                    (text.isupper() or re.search(r"(?i)DO NOT|UNLESS|REMOVE|BREAK|AVOID", text))):
                continue
        notes.append(DrawingNote(id=f"note_p{page}_{index:04d}", text=text, kind=kind,
                                 page=page, bbox=bbox, confidence=confidence,
                                 source="ocr" if block.get("source") == "ocr" else "pdf_text"))
    return notes, general, materials, finishes
