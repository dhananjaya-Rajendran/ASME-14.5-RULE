"""Model verification helpers used by the optional explicit CLI check."""
from pathlib import Path
from tempfile import TemporaryDirectory

from gdt_validator.vision.extraction_prompt import DRAWING_EXTRACTION_PROMPT
from gdt_validator.vision.model_config import ModelConfig, verify_adapter_compatibility
from gdt_validator.vision.vlm_client import create_vlm_client


def verify_model(config: ModelConfig | None = None, image_path: str | None = None) -> dict:
    """Load/check configured processor and perform a small vision inference.

    This is intentionally explicit because loading a multi-billion parameter
    model during every ordinary CLI startup would be disruptive.
    """
    config = config or ModelConfig.from_env()
    config.validate()
    if config.backend == "transformers" and config.adapter_path:
        verify_adapter_compatibility(config.production_model, config.adapter_path)
    client = create_vlm_client(config)
    temporary: TemporaryDirectory | None = None
    if image_path is None:
        try:
            from PIL import Image
        except ImportError as exc:
            raise RuntimeError("Pillow is required for the synthetic vision verification image.") from exc
        temporary = TemporaryDirectory(prefix="gdt-vlm-verify-")
        image_path = str(Path(temporary.name) / "verification.png")
        Image.new("RGB", (224, 224), "white").save(image_path)
    try:
        output = client.analyze_drawing(image_path, DRAWING_EXTRACTION_PROMPT)
        if not isinstance(output, dict):
            raise ValueError("VLM inference verification did not return a JSON object.")
        return {"backend": config.backend,
                "base_model": (config.production_model if config.backend == "transformers"
                               else config.ollama_model if config.backend == "ollama" else "mock"),
                "adapter": config.adapter_path,
                "fine_tuned": bool(config.adapter_path),
                "inference_verified": config.backend != "mock",
                "verification_mode": "software_mock" if config.backend == "mock" else "model_inference"}
    finally:
        if temporary:
            temporary.cleanup()
