"""Manually mark GD&T symbol spans in OCR/plain text for NER training.

Run from the project root: python -m gdt_validator.tools.annotate_symbols
Or from gdt_validator: python tools/annotate_symbols.py
Select a label, then drag across the exact symbol text. Ctrl+S saves; Next moves on.
"""

import argparse
import json
from pathlib import Path
import tkinter as tk
from tkinter import ttk

LABELS = [
    "CHARACTERISTIC", "DIAMETER", "DATUM", "MATERIAL_CONDITION",
    "TOLERANCE_VALUE", "DATUM_REFERENCE", "FEATURE_CONTROL_FRAME",
]


class TextAnnotator:
    def __init__(self, root, output: Path, initial_text: str = ""):
        self.root, self.output = root, output
        self.rows = self._load()
        self.index = 0
        if initial_text.strip():
            self.rows.append({"text": initial_text.strip(), "entities": []})
        if not self.rows:
            self.rows.append({"text": "", "entities": []})
        root.title("GD&T Text NER Annotator")
        root.geometry("980x650")
        bar = ttk.Frame(root, padding=8); bar.pack(fill="x")
        ttk.Label(bar, text="Entity").pack(side="left")
        self.label = tk.StringVar(value=LABELS[0])
        ttk.Combobox(bar, textvariable=self.label, values=LABELS, state="readonly", width=28).pack(side="left", padx=6)
        ttk.Button(bar, text="Add text", command=self.add_text).pack(side="left", padx=4)
        ttk.Button(bar, text="Save", command=self.save).pack(side="left", padx=4)
        ttk.Button(bar, text="Previous", command=lambda: self.move(-1)).pack(side="left", padx=4)
        ttk.Button(bar, text="Next", command=lambda: self.move(1)).pack(side="left", padx=4)
        ttk.Label(root, text="Paste OCR/text below. Select a label, then drag over its exact character span. Use Ctrl+S to save.", padding=8).pack(anchor="w")
        self.editor = tk.Text(root, wrap="word", font=("Consolas", 15), undo=True)
        self.editor.pack(fill="both", expand=True, padx=10, pady=5)
        self.editor.tag_configure("entity", background="#ffe28a")
        self.editor.bind("<ButtonRelease-1>", self.selection_changed)
        root.bind("<Control-s>", lambda _e: self.save())
        self.status = ttk.Label(root, padding=8); self.status.pack(fill="x")
        self.load_row()

    def _load(self):
        if not self.output.exists(): return []
        rows=[]
        for n,line in enumerate(self.output.read_text(encoding="utf-8").splitlines(),1):
            if line.strip():
                row=json.loads(line)
                if not isinstance(row.get("text"),str) or not isinstance(row.get("entities"),list):
                    raise ValueError(f"Invalid annotation record on line {n}")
                rows.append(row)
        return rows

    def sync_text(self):
        self.rows[self.index]["text"] = self.editor.get("1.0", "end-1c")

    def load_row(self):
        row=self.rows[self.index]
        self.editor.delete("1.0", "end"); self.editor.insert("1.0", row["text"])
        self.refresh()

    def refresh(self):
        self.editor.tag_remove("entity", "1.0", "end")
        for ent in self.rows[self.index]["entities"]:
            self.editor.tag_add("entity", f"1.0+{ent['start']}c", f"1.0+{ent['end']}c")
        self.status.config(text=f"{self.index+1}/{len(self.rows)} | {len(self.rows[self.index]['entities'])} span(s) | {self.output}")

    def selection_changed(self, _event=None):
        try:
            a=self.editor.count("1.0", "sel.first", "chars")[0]
            b=self.editor.count("1.0", "sel.last", "chars")[0]
            if a < b:
                self.sync_text()
                self.rows[self.index]["entities"].append({"start":a,"end":b,"label":self.label.get()})
                self.refresh()
        except tk.TclError: pass

    def add_text(self):
        text=simple_text_dialog(self.root)
        if text is not None:
            self.sync_text()
            self.rows.append({"text":text,"entities":[]}); self.index=len(self.rows)-1; self.load_row()

    def save(self):
        self.sync_text(); self.output.parent.mkdir(parents=True,exist_ok=True)
        self.output.write_text("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in self.rows),encoding="utf-8")
        self.status.config(text=f"Saved {len(self.rows)} text record(s) to {self.output}")

    def move(self, delta):
        self.sync_text(); self.index=(self.index+delta)%len(self.rows); self.load_row()


def simple_text_dialog(root):
    win=tk.Toplevel(root); win.title("Add text sample"); win.geometry("700x350")
    box=tk.Text(win,wrap="word",font=("Consolas",12)); box.pack(fill="both",expand=True,padx=8,pady=8)
    result={"value":None}
    def accept(): result["value"]=box.get("1.0","end-1c").strip(); win.destroy()
    ttk.Button(win,text="Add sample",command=accept).pack(pady=6)
    win.transient(root); win.grab_set(); root.wait_window(win)
    return result["value"]


def main():
    p=argparse.ArgumentParser(description=__doc__)
    default_out = Path(__file__).resolve().parents[1] / "data" / "gdt_ner.jsonl"
    p.add_argument("--out",default=str(default_out),help="Annotation JSONL output")
    p.add_argument("--text",help="Start with a text sample (otherwise use Add text)")
    args=p.parse_args()
    out=Path(args.out).expanduser().resolve()
    try:
        root=tk.Tk(); app=TextAnnotator(root,out,args.text or ""); root.mainloop()
    except KeyboardInterrupt:
        # Ctrl+C can stop Tk's event loop in a terminal. Save first so annotations
        # already entered are not lost, then exit without dumping a traceback.
        try:
            app.save()
        except (UnboundLocalError, tk.TclError):
            pass
        print("Annotation window stopped.")


if __name__=="__main__": main()
