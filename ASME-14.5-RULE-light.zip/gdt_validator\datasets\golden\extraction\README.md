# Golden extraction dataset

Place one JSON object per line in `benchmark.jsonl`, with `image`, `drawing_id`, `label_status: EXPERT_VERIFIED`, and an `expected` object. Each row should represent one annotated crop or explicitly described drawing page. Include only fields that were reviewed by a GD&T-capable engineer. The evaluator refuses unverified labels.

No golden labels or drawing images are present yet; therefore baseline metrics remain NOT RUN.
