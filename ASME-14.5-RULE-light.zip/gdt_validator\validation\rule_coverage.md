# Rule coverage audit

The engine is a conservative subset and must not be represented as full ASME Y14.5 certification. Clause references are informational pointers for reviewer verification.

| Topic | State | Current behavior |
|---|---|---|
| Missing dimension tolerance | Implemented, limited | Warns when extraction explicitly says no tolerance and no recognized exception/general tolerance applies. |
| Form control datum references | Implemented | Flags extracted datum references on flatness, straightness, circularity, and cylindricity controls. |
| Referenced datum absent from extracted declarations | Implemented, review warning | Extraction can miss datum symbols; finding is not a definitive drawing defect. |
| MMC/LMC feature-of-size applicability | Partial | Uses extracted feature classification and conservative review when unknown. |
| Position/orientation/profile/runout datum presence | Partial | Missing extracted references request review; no complete semantic FCF interpretation. |
| FCF tolerance presence/positive value | Implemented | Requires source verification for absent or nonpositive value. |
| Duplicate datum letter and >3 references | Implemented, syntax-level | Checks extracted sequence only. |
| Diameter tolerance zone by characteristic | Partial | Flags diameter zones on form controls; full characteristic-specific zone semantics are not encoded. |
| Datum sequence/precedence validity | Not implemented | Requires full datum feature and simulator semantics. |
| Basic dimension relationships | Not implemented | Dimensions are not reliably associated with controlled features. |
| Hole pattern consistency | Not implemented | No robust pattern/feature association model. |
| Duplicate/conflicting tolerances | Not implemented | Requires feature identity and geometric association. |
| Geometric acceptance/math from measured geometry | Not implemented | PDF annotations alone do not provide CAD/CMM geometry. |

## Architectural audit

Existing modules are present for CLI/GUI orchestration, vector FCF and datum detection, leader tracing, Qwen/Ollama vision, optional OCR+NER, RAG knowledge retrieval, PDF annotation/report generation, and feedback storage. This remains a desktop/CLI workflow with no API endpoint layer. Focused automated tests cover extraction, VLM configuration, and the RAG decision boundary.

No independent review of ASME copyrighted normative text was performed. Rule conclusions are limited to explicit extracted fields and should be checked against the contractually applicable edition by a qualified reviewer.

All current registry entries are marked `UNDER_REVIEW`. They are useful candidate checks but cannot support a production `PASS` or `FAIL` until an authorized engineering review changes their metadata to `EXPERT_VERIFIED`. No golden dataset with expert-approved expected results is present.

The implemented structural candidate checks are isolated as Python functions in `validation/rules/structural.py` and orchestrated by `ASMEY145RuleEngine`. The registry currently contains 13 rule IDs inherited from the existing subset. They are not considered approved compliance rules; each emitted finding is downgraded to review until expert verification. The primary drawing result uses `PASS`, `FAIL`, or `INSUFFICIENT_INFORMATION`.
