import pymupdf

from gdt_validator.main import run_pipeline


def test_synthetic_pdf_runs_through_pipeline_to_report_in_mock_mode(tmp_path, monkeypatch):
    pdf = tmp_path / "synthetic_drawing.pdf"
    document = pymupdf.open()
    page = document.new_page(width=600, height=800)
    page.insert_text((50, 50), "DWG NO: MOCK-001")
    page.insert_text((50, 80), "DIA 12 +/-0.1")
    document.save(pdf)
    document.close()

    monkeypatch.setenv("MOCK_MODE", "true")
    result = run_pipeline(str(pdf), output_dir=str(tmp_path / "output"))

    assert result["validation_status"] == "INSUFFICIENT_INFORMATION"
    assert result["drawing"].drawing_id == "synthetic_drawing"
    assert result["drawing"].dimensions
    assert result["validation_result"].status == "INSUFFICIENT_INFORMATION"
    assert (tmp_path / "output" / "synthetic_drawing" / "report.pdf").is_file()
    assert (tmp_path / "output" / "synthetic_drawing" / "annotated.pdf").is_file()
