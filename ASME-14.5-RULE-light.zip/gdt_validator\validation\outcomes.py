"""Three-state drawing outcome aggregation, independent of RAG and UI."""
from gdt_validator.models.drawing_ir import CompletenessResult
from gdt_validator.schemas import RuleDecision, ValidationResult, ValidationViolation
from gdt_validator.validation.rule_registry import RULE_REGISTRY


def build_validation_result(drawing_id: str, completeness: CompletenessResult,
                            violations: list[ValidationViolation],
                            decisions: list[RuleDecision]) -> ValidationResult:
    """Fail closed unless all evaluated production rules are approved and complete."""
    if any(item.status == "FAIL" for item in violations):
        status = "FAIL"
        message = "One or more expert-verified deterministic rules failed."
    elif (completeness.status != "READY"
          or any(item.status in {"REVIEW_REQUIRED", "WARNING"} for item in violations)
          or not RULE_REGISTRY
          or any(rule.verification_status != "EXPERT_VERIFIED"
                 for rule in RULE_REGISTRY.values())):
        status = "INSUFFICIENT_INFORMATION"
        message = "Extraction is incomplete or one or more enabled checks are not expert verified."
    else:
        status = "PASS"
        message = "All configured expert-verified deterministic checks passed."
    return ValidationResult(drawing_id=drawing_id, status=status, findings=decisions,
                            registered_rule_count=len(RULE_REGISTRY), message=message)
