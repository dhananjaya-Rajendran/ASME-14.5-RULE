"""Configured drawing standard identity used by validation and reference lookup."""
from dataclasses import dataclass


@dataclass(frozen=True)
class StandardIdentity:
    family: str
    edition: str

    @property
    def display_name(self) -> str:
        return f"{self.family}{self.edition}"


# The repository's current rule clauses and local knowledge archive target this
# edition. Changing editions requires a reviewed ruleset and corresponding KB.
PROJECT_STANDARD = StandardIdentity(family="ASME Y14.5", edition="M-1994")
