from dataclasses import replace

from gdt_validator.evaluation.evaluate_vlm import evaluate
from gdt_validator.models.drawing_ir import CompletenessResult
from gdt_validator.schemas import ValidationViolation
from gdt_validator.validation.outcomes import build_validation_result
from gdt_validator.validation.rule_registry import RULE_REGISTRY


class FixedClient:
    def analyze_drawing(self, image, prompt):
        return {"characteristic_symbol": "position", "tolerance_value": 0.1,
                "diameter_zone": True, "material_condition": "MMC",
                "datums": ["A", "B", "C"], "associated_feature_type": "hole",
                "is_feature_of_size": True, "has_size_tolerance_on_feature": True,
                "confidence": 0.99, "review_required": False, "bbox": [0, 0, 10, 10]}


def test_extraction_benchmark_reports_separate_detection_and_field_metrics():
    result = evaluate(FixedClient(), [{"drawing_id": "crop-1", "_image": "synthetic.png",
        "expected": {"characteristic_symbol": "position", "tolerance_value": 0.1,
                     "diameter_zone": True, "material_condition": "MMC",
                     "datums": ["A", "B", "C"], "feature_control_frame": True,
                     "bbox": [0, 0, 10, 10]}}])
    assert result["status"] == "MEASURED"
    assert result["fcf_detection"]["f1"] == 1.0
    assert result["datum_detection"]["f1"] == 1.0
    assert result["field_accuracy"]["tolerance_value"] == 1.0
    assert result["json_validity"] == 1.0


def test_no_unverified_rules_can_produce_primary_pass():
    assert all(item.verification_status == "UNDER_REVIEW" for item in RULE_REGISTRY.values())
    result = build_validation_result("dwg", CompletenessResult(status="READY"), [], [])
    assert result.status == "INSUFFICIENT_INFORMATION"
    assert result.registered_rule_count == len(RULE_REGISTRY)


def test_primary_pass_fail_and_insufficient_outcomes_are_deterministic(monkeypatch):
    for rule_id, metadata in list(RULE_REGISTRY.items()):
        monkeypatch.setitem(RULE_REGISTRY, rule_id,
                            replace(metadata, verification_status="EXPERT_VERIFIED"))
    ready = CompletenessResult(status="READY")
    passed = build_validation_result("dwg", ready, [], [])
    assert passed.status == "PASS"

    violation = ValidationViolation(rule_id="ASME-Y14.5-FORM-001", severity="ERROR",
        fcf_id="FCF-1", bbox=[0, 0, 1, 1], description="Deterministic failure",
        asme_clause_reference="ASME Y14.5 Section 6.4", status="FAIL")
    failed = build_validation_result("dwg", ready, [violation], [])
    assert failed.status == "FAIL"
    incomplete = build_validation_result("dwg", CompletenessResult(status="REVIEW_REQUIRED"), [], [])
    assert incomplete.status == "INSUFFICIENT_INFORMATION"
