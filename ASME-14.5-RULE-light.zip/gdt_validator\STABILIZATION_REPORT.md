# Stabilization, benchmark, and validation report

## Implementation status

The pre-change findings are in [IMPLEMENTATION_GAP_REPORT.md](IMPLEMENTATION_GAP_REPORT.md). Changes below stabilize the existing `gdt_validator` package; they do not establish full Y14.5 compliance.

| Area | Status | Evidence |
|---|---|---|
| Imports and syntax | PASS | Main pipeline, evaluators, and rule engine imports checked; `compileall` completed. |
| Synthetic PDF pipeline | PASS | Mock-mode integration test creates a PDF, extracts text, runs deterministic orchestration, and produces report and annotated PDF. |
| Mock mode | PASS | `MOCK_MODE=true` selects the mock backend and unresolved datum crops remain unknown. |
| Primary validation contract | PASS | `ValidationResult` is exactly `PASS`, `FAIL`, or `INSUFFICIENT_INFORMATION`; aggregation tests cover all three. |
| Deterministic rules | PARTIAL | Existing structural checks are now independent Python functions; 13 registry IDs remain `UNDER_REVIEW`. Their findings are downgraded to review and cannot claim production PASS/FAIL. |
| Extraction benchmark | NOT RUN | Dataset contains no labeled drawings. Report: `reports/baseline_qwen25vl_report.md`. |
| Rule benchmark | NOT RUN | No expert-verified structured validation cases. |
| Real Qwen PDF end-to-end | NOT VERIFIED | No real drawing was provided and the test interpreter lacks the Ollama Python client. The synthetic smoke test is not model accuracy evidence. |
| Expert verification | NOT AVAILABLE | No authorized reviewer approval or verified gold data was supplied. |

## Architecture changes

- Centralized the active rules/reference identity as ASME Y14.5M-1994 in `standards.py`.
- Kept the configured baseline model as the existing Ollama Qwen2.5-VL 7B tag; the benchmark loads the base model only and does not load a LoRA adapter.
- Added the `MOCK_MODE=true` environment switch and routed datum extraction through the configured VLM interface instead of a direct Ollama import.
- Split existing dimension/FCF structure checks into deterministic functions under `validation/rules/structural.py`.
- Added a three-state `ValidationResult` contract. RAG still runs only after deterministic results and returns separate explanation records.
- Added independent extraction and structured-rule evaluation commands. Each refuses unverified labels. Empty data produces `NOT_RUN`.
- Added project-proposed extraction targets in `evaluation/thresholds.json`; they are not Y14.5 criteria and require owner approval before use as release gates.

## Verification commands and results

```powershell
python -m pytest -v
python -m compileall -q . -x 'gdt_env|\.venv|__pycache__'
python -m gdt_validator.evaluation.evaluate_vlm
python -m gdt_validator.evaluation.evaluate_rules
```

Result: **27 tests passed**; compilation and critical imports succeeded. Both evaluation commands emitted `NOT_RUN` because there are no expert-verified benchmark examples. No Qwen model inference was made during benchmark generation.

## Commands to run next

Run the base-model extraction benchmark after adding expert-labeled crops and images to `datasets/golden/extraction/benchmark.jsonl`:

```powershell
python -m gdt_validator.evaluation.evaluate_vlm --dataset gdt_validator\datasets\golden\extraction\benchmark.jsonl --backend ollama --model qwen2.5vl:7b
```

Run deterministic rule evaluation after adding expert-approved structured cases:

```powershell
python -m gdt_validator.evaluation.evaluate_rules --dataset gdt_validator\datasets\golden\validation\benchmark.jsonl
```

Smoke-test without a GPU or external model:

```powershell
$env:MOCK_MODE = "true"
python -m pytest -v
```

## Remaining requirements before a production baseline

1. Supply an authorized representative drawing PDF and a reachable configured Qwen model to verify real PDF-to-VLM execution.
2. Create and independently approve extraction labels and validation outcomes. Do not mark labels `EXPERT_VERIFIED` without that review.
3. Have a qualified GD&T reviewer verify each deterministic rule against the contractually applicable licensed edition. All current registry rules remain `UNDER_REVIEW`.
4. Expand rule testing using approved positive, negative, boundary, and missing-information cases; evaluate RAG retrieval separately from rule accuracy.
5. Measure the base model on a held-out set and inspect the error taxonomy before considering LoRA.

Until these requirements are met, the system's primary status is intentionally `INSUFFICIENT_INFORMATION` for unverified rules or incomplete extraction. The reports make no claims of benchmark accuracy or comprehensive ASME compliance.
