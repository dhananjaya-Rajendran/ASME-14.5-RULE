from typing import Any, Dict, List, Optional

import pymupdf as fitz


class OCRFallback:
    def __init__(self, dpi: int = 150, engine=None):
        self.dpi = dpi
        self.engine = engine

    def extract_page(self, page: fitz.Page) -> List[Dict[str, Any]]:
        if self.engine is None:
            from rapidocr_onnxruntime import RapidOCR
            self.engine = RapidOCR()
        pix = page.get_pixmap(dpi=self.dpi)
        result, _ = self.engine(pix.tobytes("png"))
        if not result:
            return []
        scale = 72.0 / self.dpi
        blocks = []
        for box, text, score in result:
            xs = [point[0] for point in box]
            ys = [point[1] for point in box]
            blocks.append({
                "bbox": (min(xs) * scale, min(ys) * scale,
                         max(xs) * scale, max(ys) * scale),
                "text": text,
                "confidence": float(score),
            })
        return blocks
