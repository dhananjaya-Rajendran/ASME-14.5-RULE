# Drawing extraction coverage

The pipeline is intentionally partial. It retains source text, page, bounding box, source type, and confidence where available. It does not infer missing engineering facts.

| Element | Extracted | Normalized | Tested | Rule consumer | Current limit |
|---|---|---|---|---|---|
| Linear/diameter/radius/angular/chamfer/depth/thread dimensions | Partial | Supported forms only | Yes | Dimension missing-tolerance rule | Arc/chord/coordinate/chain/baseline semantics and graphical stacked limits are unsupported. |
| Tolerances | Partial | Bilateral/unilateral explicit text; general tolerance note retained separately | Yes | Dimension missing-tolerance check | No robust title-block table interpretation or complete general-tolerance application. |
| Features | No | N/A | No | No | Geometry-based feature detection not implemented. |
| FCF / GD&T | Existing crop detector + VLM/NER path | Existing FCF schema | Existing and model tests | Yes, limited rules | Composite frames, projected zones, unequal disposition, complete FCF cell structure unsupported. |
| Datums | Existing vector symbol candidates and OCR/VLM/NER labels | Letter list / partial datum records | Existing tests not available | Yes, limited references | Datum feature geometry, targets, role, and association unsupported. |
| Hole callouts | Partial explicit text patterns | Diameter, quantity, depth, through, thread | Yes | No complete pattern rule | Does not establish geometry or link callout to a feature. |
| Patterns | Partial textual quantity/PCD clues | Limited pattern record | Yes | No | No grouping of individual holes or spatial confirmation. |
| Surface finish | Partial Ra text | Ra value and source | Yes via IR PDF fixture | No | Surface symbol geometry and feature relation unsupported. |
| Notes/material | Partial text and keyword categories | Source-linked note/material records | Yes via IR fixture for notes | No | Heat treatment/hardness/coating distinctions incomplete; no inference. |
| Title block | Partial labeled values | Drawing metadata | Yes via IR fixture | No | Layout-specific cells, dates, personnel, scale, and title are not reliably parsed. |
| Views | Explicit printed labels only | Section/detail/front etc label records | Yes via IR fixture | No | View boundaries, unlabeled orthographic view types, and geometric extents unsupported. |
| Relations | No | N/A | Completeness gate tested | Indirectly needed by future rules | Feature association engine not implemented; proximity is not treated as proof. |

The completeness gate returns `REVIEW_REQUIRED` when any required extraction component is partial, undetected, failed, or not implemented. The current pipeline can still report rule outcomes for explicitly extracted FCFs/dimensions, but it does not return an overall pass for an incomplete drawing representation.
