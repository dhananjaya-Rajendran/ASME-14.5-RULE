"""Provider-neutral visual extraction clients. No client makes ASME decisions."""
import json
import logging
from functools import lru_cache
from typing import Any, Dict, Protocol

from gdt_validator.vision.extraction_prompt import DRAWING_EXTRACTION_PROMPT
from gdt_validator.vision.model_config import ModelConfig

logger = logging.getLogger(__name__)


def _parse_json_object(content: Any) -> Dict[str, Any]:
    """Parse a JSON object, tolerating common Markdown/prose wrappers from VLMs."""
    if isinstance(content, dict):
        return content
    if not isinstance(content, str) or not content.strip():
        raise ValueError("VLM response must contain a JSON object.")

    text = content.strip().lstrip("\ufeff")
    try:
        value = json.loads(text)
    except json.JSONDecodeError:
        # Models sometimes ignore JSON mode and wrap the object in a code fence
        # or a short preamble. Extract the first complete top-level object.
        start = text.find("{")
        if start < 0:
            raise ValueError("VLM response does not contain a JSON object.")
        depth = 0
        in_string = False
        escaped = False
        end = None
        for index in range(start, len(text)):
            char = text[index]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = False
                continue
            if char == '"':
                in_string = True
            elif char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    end = index + 1
                    break
        if end is None:
            raise ValueError("VLM response contains an incomplete JSON object.")
        try:
            value = json.loads(text[start:end])
        except json.JSONDecodeError as exc:
            raise ValueError("VLM response contains malformed JSON.") from exc

    if not isinstance(value, dict):
        raise ValueError("VLM response must be a JSON object.")
    return value


class VLMClient(Protocol):
    def analyze_drawing(self, image: Any, prompt: str) -> Dict[str, Any]: ...


class OllamaVLMClient:
    def __init__(self, model: str | None = None, timeout: float = 120.0):
        self.model = model or ModelConfig.from_env().ollama_model
        self.timeout = timeout

    def analyze_drawing(self, image: Any, prompt: str) -> Dict[str, Any]:
        try:
            import ollama
            response = ollama.chat(model=self.model,
                messages=[{"role": "user", "content": prompt, "images": [str(image)]}],
                format="json", options={"temperature": 0.0})
        except ImportError as exc:
            raise RuntimeError(
                "The Ollama Python client is missing from this interpreter. Install it "
                "with `python -m pip install ollama`, then restart the application."
            ) from exc
        except (ConnectionError, TimeoutError, OSError) as exc:
            raise RuntimeError(f"Ollama request failed: {exc}") from exc
        try:
            # Newer Ollama clients may expose parsed structured output directly;
            # older versions return the model content as a string.
            message = response.message if hasattr(response, "message") else response["message"]
            content = message.content if hasattr(message, "content") else message["content"]
            return _parse_json_object(content)
        except (KeyError, TypeError, AttributeError, ValueError) as exc:
            logger.warning("Could not parse Ollama JSON response: %s", exc)
            raise ValueError("Ollama returned malformed JSON. Check the model output and retry.") from exc


class MockVLMClient:
    """Safe mock returning unknowns until a test injects known labeled output."""
    def __init__(self, response: dict | None = None):
        self.response = response or {
            "characteristic_symbol": "unknown", "tolerance_value": None,
            "diameter_zone": False, "material_condition": None, "datums": [],
            "associated_feature_type": "unknown", "is_feature_of_size": None,
            "has_size_tolerance_on_feature": None, "confidence": 0.0,
            "review_required": True,
        }

    def analyze_drawing(self, image: Any, prompt: str) -> Dict[str, Any]:
        return dict(self.response)


@lru_cache(maxsize=4)
def create_vlm_client(config: ModelConfig | None = None) -> VLMClient:
    config = config or ModelConfig.from_env()
    config.validate()
    if config.backend == "mock":
        logger.info("VLM backend=mock; extraction defaults to review-required")
        return MockVLMClient()
    if config.backend == "ollama":
        logger.info("VLM base=%s adapter=none backend=ollama", config.ollama_model)
        return OllamaVLMClient(model=config.ollama_model)
    from gdt_validator.vision.transformers_vlm import TransformersVLMClient
    logger.info("VLM base=%s adapter=%s backend=transformers fine_tuned=%s device=%s",
                config.production_model, config.adapter_path or "none",
                bool(config.adapter_path), config.device)
    return TransformersVLMClient(config)


def analyze_roi_with_qwen(image_path: str, raw_text: str, roi_id: str,
                          bbox: list, model: str | None = None,
                          client: VLMClient | None = None) -> Dict[str, Any]:
    """Legacy-compatible function name; dispatches to the configured VLM backend."""
    configured = ModelConfig.from_env()
    if model:
        # Preserve the CLI's historical Ollama model override.
        configured = ModelConfig(**{**configured.__dict__, "ollama_model": model})
    client = client or create_vlm_client(configured)
    prompt = (DRAWING_EXTRACTION_PROMPT + f"\nROI ID: {roi_id}\n"
              f"Raw PDF text (may be incomplete): {raw_text}\n"
              "Return only fields readable from the visual source.")
    data = client.analyze_drawing(image_path, prompt)
    allowed = {
        "flatness", "straightness", "circularity", "cylindricity", "perpendicularity",
        "parallelism", "angularity", "position", "profile_of_a_line",
        "profile_of_a_surface", "circular_runout", "total_runout", "concentricity",
        "symmetry", "unknown",
    }
    characteristic = str(data.get("characteristic_symbol", "unknown")).strip().lower()
    data["characteristic_symbol"] = characteristic if characteristic in allowed else "unknown"
    value = data.get("tolerance_value")
    if not isinstance(value, (int, float)) or isinstance(value, bool) or value <= 0:
        data["tolerance_value"] = None
    if data.get("material_condition") not in {"RFS", "MMC", "LMC"}:
        data["material_condition"] = None
    data.setdefault("datums", [])
    data.setdefault("diameter_zone", False)
    data.setdefault("associated_feature_type", "unknown")
    data.setdefault("is_feature_of_size", None)
    data.setdefault("has_size_tolerance_on_feature", None)
    confidence = data.get("confidence", 0.0)
    if isinstance(confidence, bool) or not isinstance(confidence, (int, float)):
        confidence = 0.0
    data["confidence"] = min(1.0, max(0.0, float(confidence)))
    datums = []
    for datum in data["datums"]:
        if isinstance(datum, str):
            datum = {"datum_letter": datum}
        if isinstance(datum, dict) and datum.get("datum_letter"):
            if datum.get("material_condition") not in {"RFS", "MMC", "LMC"}:
                datum["material_condition"] = "RFS"
            datums.append(datum)
    data["datums"] = datums
    data.update({"id": roi_id, "bbox": bbox, "source": "vision",
                 "review_required": bool(data.get("review_required", False)
                                          or data["confidence"] < 0.90)})
    return data


def generate_report_narrative(drawing, violations, model: str | None = None) -> Dict[str, str]:
    """Ask Ollama to explain fixed findings; this is not used to create decisions."""
    import ollama
    model = model or ModelConfig.from_env().ollama_model
    findings = [{"rule_id": item.rule_id, "severity": item.severity,
                 "fcf_id": item.fcf_id, "description": item.description,
                 "reference": item.asme_clause_reference,
                 "remediation": item.remediation_action,
                 "retrieved_source_context": item.knowledge_context} for item in violations]
    payload = json.dumps({"standard": drawing.applicable_standard,
                          "drawing_id": drawing.drawing_id,
                          "fcf_count": len(drawing.feature_control_frames),
                          "findings": findings}, ensure_ascii=False)
    response = ollama.chat(model=model, messages=[{"role": "user", "content": (
        "Summarize only the deterministic findings in this JSON. Do not add or alter "
        "findings or claim full compliance. Return JSON with summary and review_note.\n" + payload)}],
        format="json", options={"temperature": 0.0})
    try:
        message = response.message if hasattr(response, "message") else response["message"]
        content = message.content if hasattr(message, "content") else message["content"]
        narrative = _parse_json_object(content)
        return {"summary": str(narrative["summary"]).strip(),
                "review_note": str(narrative["review_note"]).strip()}
    except (KeyError, TypeError, json.JSONDecodeError) as exc:
        raise ValueError("Narrative model returned malformed JSON.") from exc
