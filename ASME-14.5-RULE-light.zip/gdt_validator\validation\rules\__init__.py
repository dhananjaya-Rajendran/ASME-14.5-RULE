"""Independently testable deterministic checks over structured drawing fields."""
