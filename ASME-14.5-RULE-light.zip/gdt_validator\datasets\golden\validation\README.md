# Golden deterministic validation dataset

Use one JSON object per line with a serialized `drawing_ir`, a human-approved `expected_status` (`PASS`, `FAIL`, or `INSUFFICIENT_INFORMATION`), and `label_status: EXPERT_VERIFIED`. Expected outcomes must be independently reviewed against the project's licensed applicable ASME edition. No approved cases are currently available.
