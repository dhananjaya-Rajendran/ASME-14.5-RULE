# ASME Y14.5 GD&T Validator

A local Python desktop and command-line tool for extracting feature control frames (FCFs) from engineering drawing PDFs and checking supported GD&T rules. The runtime can use a base Qwen vision model through Ollama or a Qwen2.5-VL model plus a PEFT adapter through Transformers. **YOLO is not used or required.**

The validator performs a limited automated review. It does not establish full drawing compliance; review the drawing and applicable standard with a qualified reviewer.

## Requirements

- Windows, Python 3.10–3.13 for the TensorFlow runtime, and a working Tkinter installation for the desktop app. The current Python 3.14 `gdt_env` is not compatible with TensorFlow; create a separate environment with Python 3.10–3.13.
- Ollama running locally, with a vision-capable model such as `qwen2.5vl:7b` installed.
- Python dependencies from `gdt_validator/requirements.txt`.
- An authorized copy of the applicable ASME standard if you want to build the local standards knowledge base. The current default knowledge-base edition is ASME Y14.5M-1994.

The deterministic core uses Pydantic schemas and the ASME subset rule engine. The optional NER training/inference tooling has additional TensorFlow version constraints and may require Python 3.10–3.13; check the target interpreter separately.

## VLM and LoRA model configuration

The prior repository trained against `Qwen/Qwen2.5-VL-3B-Instruct` but defaulted to the unrelated `qwen2.5vl:7b` Ollama model. A 3B PEFT adapter must not be loaded on the 7B model. Training and Transformers inference now share `TRAINING_MODEL` and `VLM_BASE_MODEL`, defaulting to the 3B model. Ollama remains an independent base-model path and defaults to `qwen2.5vl:7b` without a PEFT adapter.

Copy `gdt_validator/.env.example` to a private environment setup file or set the variables in your shell. The application reads process environment variables. For the existing Ollama base-model route, keep `VLM_BACKEND=ollama`. To use the trained adapter, set:

```text
VLM_BACKEND=transformers
VLM_BASE_MODEL=Qwen/Qwen2.5-VL-3B-Instruct
VLM_ADAPTER_PATH=outputs/lora_symbols/final
VLM_DEVICE=auto
```

Install optional inference/training dependencies from `gdt_validator/requirements-vlm.txt` after installing a PyTorch build suited to your CPU/CUDA platform. Train with the same base model:

```powershell
python "gdt_validator\Train symbol lora.py" --data "gdt_validator\datasets\train.jsonl" --base-model "Qwen/Qwen2.5-VL-3B-Instruct"
```

The training JSONL contains human-labeled image crops and extraction JSON only. Do not include ASME pass/fail judgments in its labels. The 3B/7B compatibility check reads PEFT's adapter metadata and refuses a mismatch. Run `python -m gdt_validator.main --verify-vlm` for an explicit model/processor/inference check; it loads the configured model and may consume substantial memory.

Ollama's documented Safetensors adapter support is limited to listed model families and does not list Qwen2.5-VL. This implementation therefore uses Transformers+PEFT for direct Qwen adapter inference. See [Ollama model import documentation](https://github.com/ollama/ollama/blob/main/docs/import.md). The repository has no trained adapter yet, so fine-tuned production inference becomes available after a human-labeled dataset is trained.

The extraction client returns only visual data. Confidence below 0.90, explicit ambiguity, or missing required FCF values withholds automatic validation for manual review. Confidence below 0.70 is especially weak evidence and must be manually transcribed. The ASME rule engine remains deterministic and does not import model libraries.

## Dataset and evaluation

The `gdt_validator/datasets/` folders are scaffolding only; there are no expert-verified drawings or gold labels. Do not treat mock tests, training loss, or LLM-generated labels as extraction accuracy. The base-model evaluator does not load a LoRA adapter:

```powershell
python -m gdt_validator.evaluation.evaluate_vlm --dataset gdt_validator\datasets\golden\extraction\benchmark.jsonl
python -m gdt_validator.evaluation.evaluate_rules --dataset gdt_validator\datasets\golden\validation\benchmark.jsonl
```

Both evaluators require records marked `label_status: EXPERT_VERIFIED`. With the currently empty benchmark files they emit `NOT RUN`; no accuracy values are claimed. The extraction report is `gdt_validator/reports/baseline_qwen25vl_report.md`. Extraction, structured-rule accuracy, and end-to-end accuracy are separate measures.

Run the synthetic-PDF software integration path without Ollama or a GPU with:

```powershell
$env:MOCK_MODE = "true"
python -m pytest -v
```

Mock mode intentionally leaves uncertain datum symbols unresolved. It tests execution and fail-closed behavior; it is never counted as model benchmark evidence.

## Architecture and audit status

```text
PDF -> vector FCF/datum detection -> VLM or OCR/NER -> source-linked extraction
    -> deterministic ASME subset rules -> optional standards RAG enrichment
    -> annotated PDF + engineering report + local feedback record
```

The supported product is currently a desktop/CLI application. There is no HTTP API in this repository. Provider integration has a `VLMClient` protocol; Ollama/Qwen and Transformers Qwen are implemented adapters. `gdt_validator/validation/rule_coverage.md` records implemented, partial, and unsupported checks. The primary result is `PASS`, `FAIL`, or `INSUFFICIENT_INFORMATION`. All current rules remain `UNDER_REVIEW`, so they cannot currently produce a production PASS or FAIL.

For an architecture audit and limitations see [rule_coverage.md](gdt_validator/validation/rule_coverage.md). The repository does not claim full ASME Y14.5 compliance.

## Drawing extraction IR

The extraction pipeline runs selected-page PDF text/OCR extraction, renders a 300 DPI page image, normalizes supported annotation text into a `DrawingIR`, and reports stage-by-stage completeness before limited rule checks. The IR retains page/source/bounding-box/confidence evidence. See [extraction coverage](gdt_validator/extraction/COVERAGE.md) for each element's current status and limits.

Current text parsers cover selected linear, diameter, radius, angular, chamfer, depth, thread, explicit hole-callout, Ra surface-finish, labeled title-block, and printed view-label cases. The pipeline does not yet detect geometry-based features or relate dimensions/FCFs/datums to specific features. These stages are marked `NOT_IMPLEMENTED`; incomplete extraction maps to `INSUFFICIENT_INFORMATION`, never `PASS`.

## Setup (PowerShell)

Run from the repository root:

```powershell
# Use Python 3.10–3.13 for TensorFlow; check with: python --version
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r gdt_validator\requirements.txt
```

If PowerShell blocks activation, call the environment's Python directly instead:

```powershell
.\.venv\Scripts\python.exe -m pip install -r gdt_validator\requirements.txt
```

Install and start Ollama separately, then pull the model:

```powershell
ollama pull qwen2.5vl:7b
```

Check that the Python client can reach the Ollama service and see the model:

```powershell
python -m gdt_validator.main --check-ollama
```

Use the **same Python interpreter** to install dependencies and run the app. For example, with the repository's existing environment:

```powershell
.\gdt_env\Scripts\python.exe -m pip install -r gdt_validator\requirements.txt
```

## Start the desktop app

From the repository root:

```powershell
python -m gdt_validator.main
```

Choose a drawing PDF and output folder, select the PDF page (zero-based), and run validation. The app saves crops and generated files below the output folder, in a subfolder named after the PDF.

## Validate from the command line

```powershell
python -m gdt_validator.main --pdf "C:\drawings\part.pdf" --page 0 --output-dir output
```

Use `python -m compileall gdt_validator` to check Python syntax and `python -m pytest -v` to run the unit and synthetic-PDF integration suite.

Choose another installed Ollama model with `--model`:

```powershell
python -m gdt_validator.main --pdf "C:\drawings\part.pdf" --model qwen2.5vl:7b
```

The automatic path detects FCF regions and asks the VLM to read them. If required values are missing or uncertain, the run withholds the report and writes `manual_review.json` with source crop paths and extracted values. Check those fields against the drawing before proceeding.

### Manually reviewed FCF data

You can create a crop-linked blank JSON file for manual transcription:

```powershell
python -m gdt_validator.main --pdf "C:\drawings\part.pdf" --page 0 --create-review-template "reviewed_fcf.json"
```

Fill in the template's `characteristic_symbol`, `tolerance_value`, `material_condition`, datums, and declared datums after checking the source drawing. `material_condition` accepts `RFS`, `MMC`, or `LMC`. Then generate the report from the reviewed JSON:

```powershell
python -m gdt_validator.main --pdf "C:\drawings\part.pdf" --page 0 --reviewed-fcf-json "reviewed_fcf.json"
```

The JSON must contain a `feature_control_frames` array and a `declared_datums` array. Each frame needs an `id`, `bbox`, characteristic, tolerance, and material condition. Datum references are objects with a `datum_letter` field; a datum material condition defaults to RFS. Example:

```json
{
  "drawing_id": "part",
  "declared_datums": ["A", "B", "C"],
  "feature_control_frames": [
    {
      "id": "fcf_001",
      "bbox": [100, 200, 300, 250],
      "characteristic_symbol": "position",
      "tolerance_value": 0.25,
      "diameter_zone": true,
      "material_condition": "MMC",
      "datums": [
        {"datum_letter": "A"},
        {"datum_letter": "B"},
        {"datum_letter": "C"}
      ]
    }
  ]
}
```

## Generated files

For a drawing named `part.pdf`, the default output is under `output/part/`:

- `fcf_crops/` and `datum_crops/`: extracted regions for review.
- `manual_review.json`: unresolved automatic extraction fields, when needed.
- `annotated.pdf`: source drawing annotated with findings.
- `report.pdf`: validation summary and rule findings.
- `feedback.sqlite3`: local report feedback data.

## Standards knowledge base

Build or refresh the local OCR archive and vector index from an authorized standard PDF:

```powershell
python -m gdt_validator.main --build-kb "C:\standards\ASME_Y14_5.pdf"
```

The command reports OCR failures and index counts. The validator can also index an existing OCR archive with `--index-kb`. Use `--kb-path` and `--chroma-path` to choose storage locations.

## Manual text annotation and NER (optional)

NER can be used during PDF validation. It OCRs each detected FCF crop, combines that OCR with embedded PDF text, and maps recognized GD&T labels into FCF fields. If a field is absent or ambiguous, the run creates `manual_review.json` and withholds the report. The NER inference path uses TensorFlow. The requested Hugging Face checkpoint `erickrribeiro/bert-finetuned-ner` provides PyTorch weights only, so convert it once before using it with the TensorFlow-only runtime.

Install the project requirements (including spaCy), then annotate and train:

```powershell
python -m gdt_validator.tools.annotate_symbols --out gdt_validator/data/gdt_ner.jsonl
python -m gdt_validator.tools.train_gdt_ner train --data gdt_validator/data/gdt_ner.jsonl --out gdt_validator/models/gdt_ner
python -m gdt_validator.tools.train_gdt_ner predict --model gdt_validator/models/gdt_ner --text "POSITION ⌀0.25 M A B"
```

Add multiple OCR/plain-text samples in the annotation window, choose the entity label, and select the exact character span. Use `CHARACTERISTIC` for names such as `position`, `TOLERANCE_VALUE` for the numeric tolerance, `DIAMETER` for the diameter-zone mark, `MATERIAL_CONDITION` for `MMC` or `LMC`, and `DATUM_REFERENCE` for datum letters used in an FCF. `DATUM` is also accepted for datum letters. Save with the **Save** button or Ctrl+S. A useful NER model needs a representative set of accurately labeled examples; character-only symbols must be rendered as recognizable text by OCR or be transcribed in the training samples.

Convert the checkpoint once. This conversion environment needs TensorFlow, Transformers, and PyTorch; PyTorch is used only to convert the source weights:

```powershell
python -m pip install tensorflow tf-keras "transformers<5" torch
python -m gdt_validator.tools.convert_ner_to_tensorflow --source erickrribeiro/bert-finetuned-ner --out gdt_validator\models\bert-finetuned-ner-tf
```

Then use the converted local TensorFlow checkpoint:

```powershell
python -m gdt_validator.main --pdf "C:\drawings\part.pdf" --ner-model gdt_validator\models\bert-finetuned-ner-tf
```

In the desktop app, browse to the converted model folder in **TensorFlow NER model**. Leave this field blank to use Qwen. The supplied checkpoint is a general-purpose NER model, not one fine-tuned for GD&T. Its entity labels may not match the validator's GD&T fields. Unmapped predictions are included in `manual_review.json`; they are not treated as verified FCF values. For GD&T recognition, train a model using representative annotated drawing text. The annotation/training commands above create a local spaCy model, which can also be selected by path. NER output still goes through the manual-review gate and does not certify full drawing compliance.

## Troubleshooting

- **`No module named gdt_validator`:** run module commands from the repository root. From inside `gdt_validator`, use the script form, for example `python tools/annotate_symbols.py`.
- **`spaCy is missing`:** install requirements using the same interpreter used for NER training: `python -m pip install -r gdt_validator\requirements.txt`.
- **Ollama connection/model error:** start the Ollama service, run `ollama pull qwen2.5vl:7b`, and check with `python -m gdt_validator.main --check-ollama`.
- **No FCFs found:** verify the selected zero-based page and that the PDF contains detectable vector lines. Scanned/raster-only drawings may need OCR/vector preprocessing or manual review.
- **Report withheld:** inspect `manual_review.json` and the linked crops, fill or correct the required values, then rerun with `--reviewed-fcf-json`.
# ASME-14.5-RULE
