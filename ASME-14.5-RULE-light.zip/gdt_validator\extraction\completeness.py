"""Fail-closed gate for incomplete extraction coverage."""
from gdt_validator.models.drawing_ir import CompletenessResult, DrawingIR


def check_extraction_completeness(drawing: DrawingIR) -> CompletenessResult:
    incomplete = [stage.name for stage in drawing.extraction_metadata.stages
                  if stage.status in {"PARTIAL", "NOT_DETECTED", "NOT_IMPLEMENTED", "FAILED"}]
    if incomplete:
        return CompletenessResult(
            status="REVIEW_REQUIRED", missing_components=incomplete,
            message="Drawing extraction is incomplete; results are limited to explicitly extracted data.")
    return CompletenessResult(status="READY", missing_components=[],
                              message="All configured extraction stages reported complete.")
