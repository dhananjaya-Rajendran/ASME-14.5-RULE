"""PDF and image ingestion helpers."""
