# Stabilization and benchmark gap report

Audit completed before changes for the master implementation task. Scope: source files, package imports, prompts, config, tests, evaluation, benchmark datasets, validation registry, PDF/VLM flow, and RAG call sites. Generated output, model caches, and virtual-environment files were excluded from source review.

## Current repository state

| Area | Present | Gap / risk |
|---|---|---|
| PDF ingestion | PyMuPDF text extraction, OCR fallback, ROI detectors, page renderer | Main runs a real PDF path, but no drawing PDF was supplied to establish a successful real-model end-to-end run here. OCR/VLM fusion is absent. |
| VLM | Ollama Qwen and optional Transformers/PEFT clients; extraction-only prompt | Model defaults are duplicated (7B Ollama and 3B Transformers); no recorded baseline benchmark or hardware/model run metadata. |
| DrawingIR | Pydantic models and partial text extraction | Some fields are populated, but visual features, robust associations, and normalization remain unsupported. |
| Validation | Deterministic checks and registry | Checks are limited and currently `UNDER_REVIEW`; therefore findings are review-only. No independent pure rule module set or expert verification. |
| Result states | Legacy `PASS`/`FAIL`/`WARNING`/`REVIEW_REQUIRED`; immutable RAG boundary | Requested `INSUFFICIENT_INFORMATION` has not been made the primary engine/report status. |
| RAG | SQLite FTS and Chroma; post-decision explainer | The local archive is edition-specific; no retrieval benchmark or grounded explanation evaluation fixture. |
| Tests | 9 focused extraction, VLM config, and RAG boundary tests | No systematic positive/negative/boundary/missing-information test per rule; no full real PDF + VLM test. |
| Datasets | Dataset policy README only | No image/IR ground-truth dataset, expert-approved validation cases, or golden evaluation set. Existing `datasets/` contains no reviewed examples. |
| Evaluation | VLM evaluator for a manually labeled JSONL set | It requires an adapter, is not a baseline report generator, lacks FCF/datum/dimension taxonomy metrics, and the checked-in dataset is empty. |
| Configuration | `ModelConfig` environment support | Model identifiers are also hard-coded in UI, client defaults, training script, and evaluation CLI. Active standard edition is repeated across modules. |
| Architecture | Existing CLI/GUI modules resolve; no API layer | Target packages are adapted into existing `gdt_validator` layout. No missing import found in tested application imports. |

## Decision-path search

Search terms included TODO/FIXME/pass/NotImplementedError/mock/placeholder, ASME/Y14.5, Qwen/LoRA/PEFT/Ollama, RAG, DrawingIR, and validation/rule-engine references. No compliance prompt or path was found where LLM output sets PASS/FAIL. Before the prior boundary work, `main.py` passed deterministic violations into a mutating RAG enrichment function; it now creates deterministic decisions first and consumes separate explanation records. Current rule metadata remains `UNDER_REVIEW`, which forces review outcomes.

Some `pass` statements in `knowledge_base.py` and UI/tool exception branches are cleanup/fallback paths, not unimplemented validation rules. No `NotImplementedError` or TODO marker was found in application Python sources.

## Work that can be completed without external inputs

- Consolidate the baseline model configuration and remove duplicated defaults from application runtime paths.
- Add a small, transparent evaluation harness and machine-readable empty dataset templates; empty templates must not be reported as model results or expert labels.
- Establish a primary `PASS` / `FAIL` / `INSUFFICIENT_INFORMATION` result contract while preserving legacy report compatibility where needed.
- Add deterministic rule-focused unit tests for safe structural checks already in the code, without claiming expert approval.
- Generate a baseline report that explicitly records “NOT RUN” until a real model, drawing images, and approved labels are provided.

## External inputs required for the full acceptance criteria

- At least one representative drawing PDF and a reachable configured Qwen2.5-VL model (or explicit model run artifact) for real end-to-end verification.
- Expert-authored and reviewed extraction labels and expected validation outcomes; LLM-generated labels cannot be used as gold.
- Authorized GD&T review of each rule against the project's applicable licensed standard edition before enabling it as an expert-verified production rule.
- Benchmark runtime/hardware details and a declared test set. Without those, accuracy metrics would be fabricated.

This is a gap report, not a claim that the master task is already complete. Stabilization changes follow in the existing package structure.
