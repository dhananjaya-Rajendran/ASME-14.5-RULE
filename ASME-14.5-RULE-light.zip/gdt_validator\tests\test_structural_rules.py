import pytest

from gdt_validator.schemas import DimensionItem, FeatureControlFrame
from gdt_validator.validation.rules.structural import (
    validate_datum_declaration, validate_dimension_tolerance, validate_references,
)


def _fcf(**updates):
    values = {"id": "FCF-1", "bbox": [1, 2, 20, 10],
              "characteristic_symbol": "position", "tolerance_value": 0.1,
              "material_condition": "RFS", "confidence": 1.0, "source": "manual"}
    values.update(updates)
    return FeatureControlFrame(**values)


@pytest.mark.parametrize(("fcf", "expected_rule"), [
    (_fcf(tolerance_value=None), "ASME-Y14.5-FCF-001"),
    (_fcf(characteristic_symbol="unknown"), "ASME-Y14.5-FCF-002"),
    (_fcf(characteristic_symbol="flatness", datums=[{"datum_letter": "A"}]), "ASME-Y14.5-FORM-001"),
    (_fcf(characteristic_symbol="position", datums=[]), "ASME-Y14.5-DATUM-001"),
    (_fcf(datums=[{"datum_letter": "A"}, {"datum_letter": "A"}]), "ASME-Y14.5-DATUM-003"),
    (_fcf(datums=[{"datum_letter": "A"}, {"datum_letter": "B"},
                  {"datum_letter": "C"}, {"datum_letter": "D"}]), "ASME-Y14.5-DATUM-004"),
    (_fcf(characteristic_symbol="flatness", diameter_zone=True), "ASME-Y14.5-ZONE-001"),
    (_fcf(material_condition="MMC", is_feature_of_size=False), "ASME-Y14.5-MOD-003"),
    (_fcf(material_condition="MMC", is_feature_of_size=None), "ASME-Y14.5-MOD-005"),
    (_fcf(characteristic_symbol="flatness", material_condition="MMC"), "ASME-Y14.5-MOD-001"),
    (_fcf(material_condition="MMC", has_size_tolerance_on_feature=False), "ASME-Y14.5-MOD-004"),
])
def test_structural_fcf_rules_emit_reproducible_review_candidates(fcf, expected_rule):
    first = validate_references(fcf, "ASME Y14.5M-1994")
    second = validate_references(fcf, "ASME Y14.5M-1994")
    assert [item.model_dump() for item in first] == [item.model_dump() for item in second]
    assert expected_rule in {item.rule_id for item in first}
    assert all(item.status == "REVIEW_REQUIRED" for item in first)


def test_unlisted_datum_is_review_candidate_with_frame_source_location():
    frame = _fcf(datums=[{"datum_letter": "B"}], page=2)
    findings = validate_datum_declaration(frame, {"A"}, "ASME Y14.5M-1994")
    assert len(findings) == 1
    assert findings[0].rule_id == "ASME-Y14.5-DATUM-002"
    assert findings[0].evidence["page"] == 2


def test_dimension_tolerance_check_respects_structured_exceptions():
    ordinary = DimensionItem(id="D-1", bbox=[0, 0, 1, 1], nominal=10,
                             has_tolerance=False, confidence=1.0)
    basic = ordinary.model_copy(update={"id": "D-2", "is_basic": True})
    missing = validate_dimension_tolerance(ordinary, "ASME Y14.5M-1994")
    assert missing is not None and missing.rule_id == "ASME-Y14.5-DIM-001"
    assert validate_dimension_tolerance(basic, "ASME Y14.5M-1994") is None
    assert missing.status == "REVIEW_REQUIRED"
