import json

import pytest

from gdt_validator.vision.model_config import ModelConfig, verify_adapter_compatibility
from gdt_validator.vision.vlm_client import MockVLMClient, analyze_roi_with_qwen


def _adapter(tmp_path, base_model):
    path = tmp_path / "adapter"
    path.mkdir()
    (path / "adapter_config.json").write_text(
        json.dumps({"base_model_name_or_path": base_model}), encoding="utf-8")
    return path


def test_adapter_compatibility_accepts_exact_training_base(tmp_path):
    base = "Qwen/Qwen2.5-VL-3B-Instruct"
    verify_adapter_compatibility(base, _adapter(tmp_path, base))


def test_adapter_compatibility_rejects_three_b_adapter_for_seven_b(tmp_path):
    path = _adapter(tmp_path, "Qwen/Qwen2.5-VL-3B-Instruct")
    with pytest.raises(ValueError, match="3B adapter cannot be attached to the 7B"):
        verify_adapter_compatibility("Qwen/Qwen2.5-VL-7B-Instruct", path)


def test_peft_adapter_cannot_be_selected_with_ollama(tmp_path):
    with pytest.raises(ValueError, match="cannot be loaded by the Ollama backend"):
        ModelConfig(adapter_path=str(_adapter(tmp_path, "Qwen/Qwen2.5-VL-3B-Instruct")),
                    backend="ollama").validate()


def test_mock_mode_environment_overrides_network_backend(monkeypatch):
    monkeypatch.setenv("VLM_BACKEND", "ollama")
    monkeypatch.setenv("MOCK_MODE", "true")
    assert ModelConfig.from_env().backend == "mock"


def test_mock_extraction_is_review_required_and_never_invents_fields():
    frame = analyze_roi_with_qwen("unused.png", "", "fcf_1", [1, 2, 3, 4],
                                  client=MockVLMClient())
    assert frame["characteristic_symbol"] == "unknown"
    assert frame["tolerance_value"] is None
    assert frame["review_required"] is True
    assert frame["source"] == "vision"


def test_high_confidence_injected_mock_preserves_extraction_only_fields():
    client = MockVLMClient({
        "characteristic_symbol": "position", "tolerance_value": 0.1,
        "diameter_zone": True, "material_condition": "MMC",
        "datums": ["A", "B", "C"], "confidence": 0.96,
    })
    frame = analyze_roi_with_qwen("unused.png", "", "fcf_2", [1, 2, 3, 4], client=client)
    assert frame["characteristic_symbol"] == "position"
    assert frame["confidence"] == 0.96
    assert frame["review_required"] is False
    assert [item["datum_letter"] for item in frame["datums"]] == ["A", "B", "C"]
