"""Evaluate deterministic validation separately from image/VLM extraction."""
import argparse
import json
from pathlib import Path

from gdt_validator.extraction.completeness import check_extraction_completeness
from gdt_validator.models.drawing_ir import DrawingIR
from gdt_validator.validation.asme_rule_engine import ASMEY145RuleEngine
from gdt_validator.validation.outcomes import build_validation_result
from gdt_validator.schemas import RuleDecision
from gdt_validator.standards import PROJECT_STANDARD


def evaluate_cases(path: Path) -> dict:
    cases = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        item = json.loads(line)
        if item.get("label_status") != "EXPERT_VERIFIED":
            raise ValueError(f"Line {line_no}: validation labels must be EXPERT_VERIFIED.")
        if item.get("expected_status") not in {"PASS", "FAIL", "INSUFFICIENT_INFORMATION"}:
            raise ValueError(f"Line {line_no}: expected_status is missing or invalid.")
        drawing = DrawingIR.model_validate(item["drawing_ir"])
        drawing.completeness = check_extraction_completeness(drawing)
        violations = ASMEY145RuleEngine().validate(drawing)
        decisions = [RuleDecision(rule_id=f.rule_id, standard=PROJECT_STANDARD.family,
            edition=PROJECT_STANDARD.edition,
            status="FAIL" if f.status == "FAIL" else "INSUFFICIENT_INFORMATION",
            message=f.description, rule_confidence=f.confidence,
            reference_hint=f.asme_clause_reference)
            for f in violations]
        actual = build_validation_result(drawing.drawing_id, drawing.completeness,
                                         violations, decisions)
        cases.append({"drawing_id": drawing.drawing_id,
                      "expected": item["expected_status"], "actual": actual.status,
                      "correct": item["expected_status"] == actual.status,
                      "rule_ids": [decision.rule_id for decision in decisions]})
    if not cases:
        return {"status": "NOT_RUN", "reason": "No expert-verified validation cases.", "cases": []}
    correct = sum(case["correct"] for case in cases)
    return {"status": "MEASURED", "cases": cases, "accuracy": correct / len(cases),
            "count": len(cases), "correct": correct}


def main() -> None:
    parser = argparse.ArgumentParser(description="Measure deterministic rules on expert-reviewed DrawingIR cases.")
    parser.add_argument("--dataset", type=Path,
        default=Path(__file__).resolve().parents[1] / "datasets" / "golden" / "validation" / "benchmark.jsonl")
    parser.add_argument("--output", type=Path,
        default=Path(__file__).resolve().parents[1] / "reports" / "rule_validation_evaluation.json")
    args = parser.parse_args()
    result = evaluate_cases(args.dataset) if args.dataset.is_file() else {
        "status": "NOT_RUN", "reason": "Validation dataset is missing.", "cases": []}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
