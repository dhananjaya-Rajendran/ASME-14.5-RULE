"""Deterministic orchestration for the currently supported structural checks.

This is a limited rule set. Individual checks live in `validation.rules` and
are independently testable; registry status controls whether candidates can
be elevated beyond INSUFFICIENT_INFORMATION.
"""
from gdt_validator.schemas import DrawingExtraction, ValidationViolation
from gdt_validator.validation.rules.structural import (
    validate_datum_declaration, validate_dimension_tolerance, validate_references,
)


class ASMEY145RuleEngine:
    def validate(self, drawing: DrawingExtraction) -> list[ValidationViolation]:
        results = []
        declared = {letter.strip().upper() for letter in drawing.declared_datums}
        for dimension in drawing.dimensions:
            finding = validate_dimension_tolerance(dimension, drawing.applicable_standard)
            if finding is not None:
                results.append(finding)
        for frame in drawing.feature_control_frames:
            results.extend(validate_references(frame, drawing.applicable_standard))
            results.extend(validate_datum_declaration(
                frame, declared, drawing.applicable_standard))
        return results
