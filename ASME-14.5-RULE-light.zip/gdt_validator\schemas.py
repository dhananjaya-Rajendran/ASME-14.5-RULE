from enum import Enum
from typing import List, Literal, Optional

from pydantic import BaseModel, Field
from gdt_validator.standards import PROJECT_STANDARD


class GDTCharacteristic(str, Enum):
    FLATNESS = "flatness"
    STRAIGHTNESS = "straightness"
    CIRCULARITY = "circularity"
    CYLINDRICITY = "cylindricity"
    PERPENDICULARITY = "perpendicularity"
    PARALLELISM = "parallelism"
    ANGULARITY = "angularity"
    POSITION = "position"
    PROFILE_SURFACE = "profile_of_a_surface"
    RUNOUT = "circular_runout"


class MaterialModifier(str, Enum):
    NONE = "RFS"
    MMC = "MMC"
    LMC = "LMC"


class VerificationStatus(str, Enum):
    PASS = "PASS"
    VIOLATION = "VIOLATION"
    REQUIRES_CAD_OR_CMM = "REQUIRES_CAD_OR_CMM"


class DatumReference(BaseModel):
    datum_letter: str
    material_condition: MaterialModifier = MaterialModifier.NONE


class FeatureControlFrame(BaseModel):
    id: str
    bbox: List[float]
    characteristic_symbol: str
    tolerance_value: Optional[float] = None
    diameter_zone: bool = False
    material_condition: Optional[MaterialModifier] = None
    datums: List[DatumReference] = Field(default_factory=list)
    associated_feature_type: Literal["hole", "shaft", "planar_surface", "unknown"] = "unknown"
    is_feature_of_size: Optional[bool] = None
    has_size_tolerance_on_feature: Optional[bool] = None
    page: Optional[int] = None
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    source: Literal["vision", "ocr", "pdf_text", "fused", "manual", "unknown"] = "unknown"
    source_text: Optional[str] = None
    review_required: bool = False


class DimensionItem(BaseModel):
    id: str
    bbox: List[float]
    nominal: float
    upper_tol: float = 0.0
    lower_tol: float = 0.0
    is_basic: bool = False
    has_tolerance: Optional[bool] = None
    is_reference: bool = False
    is_maximum: bool = False
    is_minimum: bool = False
    is_stock_size: bool = False
    covered_by_general_tolerance: Optional[bool] = None
    page: Optional[int] = None
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    source: Literal["vision", "ocr", "pdf_text", "fused", "manual", "unknown"] = "unknown"
    source_text: Optional[str] = None
    dimension_type: Literal["LINEAR", "DIAMETER", "RADIUS", "ANGULAR", "ARC", "CHORD",
                            "COORDINATE", "CHAMFER", "DEPTH", "THREAD", "UNKNOWN"] = "UNKNOWN"
    unit: Optional[str] = None
    tolerance_type: Literal["BILATERAL", "UNILATERAL", "LIMITS", "GENERAL", "NONE", "UNKNOWN"] = "UNKNOWN"
    feature_id: Optional[str] = None
    view_id: Optional[str] = None


class DrawingExtraction(BaseModel):
    drawing_id: str
    applicable_standard: str = PROJECT_STANDARD.display_name
    declared_datums: List[str] = Field(default_factory=list)
    dimensions: List[DimensionItem] = Field(default_factory=list)
    feature_control_frames: List[FeatureControlFrame] = Field(default_factory=list)


class DrawingPage(BaseModel):
    page: int
    width: Optional[float] = None
    height: Optional[float] = None
    source: Literal["pdf", "image", "unknown"] = "pdf"


class DatumFeature(BaseModel):
    datum_letter: str
    feature_type: str = "unknown"
    associated_feature: Optional[str] = None
    page: Optional[int] = None
    bbox: Optional[List[float]] = None
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    source: Literal["vision", "ocr", "pdf_text", "fused", "manual", "unknown"] = "unknown"


class DrawingNote(BaseModel):
    id: str
    text: str
    kind: Literal["general_tolerance", "material", "surface_finish", "process", "other"] = "other"
    page: Optional[int] = None
    bbox: Optional[List[float]] = None
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)
    source: Literal["vision", "ocr", "pdf_text", "fused", "manual", "unknown"] = "unknown"


class DrawingData(DrawingExtraction):
    """Structured, source-aware IR passed between extraction and rule evaluation.

    `feature_control_frames` retains the established application contract and is
    the GD&T collection consumed by the deterministic rule engine.
    """
    pages: List[DrawingPage] = Field(default_factory=list)
    datums: List[DatumFeature] = Field(default_factory=list)
    notes: List[DrawingNote] = Field(default_factory=list)


class ValidationViolation(BaseModel):
    rule_id: str
    severity: Literal["ERROR", "WARNING", "REQUIRES_CAD_DATA"]
    fcf_id: str
    bbox: List[float]
    description: str
    asme_clause_reference: str
    asme_clause_excerpt: Optional[str] = None
    remediation_action: Optional[str] = None
    knowledge_context: Optional[str] = None
    status: Literal["PASS", "FAIL", "WARNING", "REVIEW_REQUIRED"] = "WARNING"
    confidence: float = Field(default=0.75, ge=0.0, le=1.0)
    evidence: Optional[dict] = None


class RuleDecision(BaseModel):
    """Immutable deterministic outcome, created before any RAG explanation."""
    model_config = {"frozen": True}
    rule_id: str
    standard: str
    edition: str
    status: Literal["PASS", "FAIL", "INSUFFICIENT_INFORMATION"]
    message: str
    evidence: tuple[dict, ...] = ()
    extraction_confidence: Optional[float] = None
    rule_confidence: Optional[float] = None
    reference_hint: Optional[str] = None


class ReferenceCitation(BaseModel):
    standard: str
    edition: str
    section: Optional[str] = None
    source_id: str
    page: Optional[int] = None
    relevance_score: Optional[float] = None
    excerpt: str


class RuleExplanation(BaseModel):
    """Post-decision retrieval and deterministic guidance, never a decision."""
    rule_id: str
    explanation_status: Literal["GROUNDED", "INSUFFICIENT_REFERENCE_EVIDENCE"]
    explanation: str
    citations: List[ReferenceCitation] = Field(default_factory=list)
    recommended_review: Optional[str] = None


class ValidationResult(BaseModel):
    """Primary machine status for one drawing: exactly three outcomes."""
    drawing_id: str
    status: Literal["PASS", "FAIL", "INSUFFICIENT_INFORMATION"]
    findings: List[RuleDecision] = Field(default_factory=list)
    registered_rule_count: int = 0
    message: str


class ValidationReport(BaseModel):
    drawing_id: str
    status: Literal["PASS", "FAIL", "WARNING", "REVIEW_REQUIRED"]
    findings: List[ValidationViolation] = Field(default_factory=list)
    rule_coverage: List[str] = Field(default_factory=list)
