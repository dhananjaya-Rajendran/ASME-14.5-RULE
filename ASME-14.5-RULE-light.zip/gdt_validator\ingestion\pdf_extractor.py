from pathlib import Path
from typing import Any, Dict

import pymupdf as fitz


class PDFExtractionError(ValueError):
    """Raised when a PDF cannot provide the requested page extraction."""


class DrawingExtractor:
    """Extract embedded page text, using OCR only when the PDF has little text."""

    def __init__(self, ocr_engine=None):
        self.ocr = ocr_engine

    def extract_text_and_rois(self, pdf_path: str, page_num: int = 0) -> Dict[str, Any]:
        text_blocks = []
        try:
            doc = fitz.open(pdf_path)
        except (RuntimeError, OSError) as exc:
            raise PDFExtractionError(f"Cannot open PDF {pdf_path!r}: {exc}") from exc
        with doc:
            if doc.is_encrypted and not doc.authenticate(""):
                raise PDFExtractionError("Encrypted PDF requires a password and is unsupported.")
            if len(doc) == 0:
                raise PDFExtractionError("PDF contains no pages.")
            if page_num < 0 or page_num >= len(doc):
                raise PDFExtractionError(f"Page index {page_num} is outside the PDF page range 0..{len(doc)-1}.")
            page = doc.load_page(page_num)
            for block in page.get_text("blocks"):
                x0, y0, x1, y1, text, _block_no, block_type = block[:7]
                if block_type == 0 and text.strip():
                    text_blocks.append({"bbox": (x0, y0, x1, y1), "text": text.strip(),
                                        "source": "pdf_text", "confidence": 0.95})
            page_rect = tuple(page.rect)
            embedded_chars = sum(len(item["text"]) for item in text_blocks)
            if not text_blocks or embedded_chars < 20:
                if self.ocr is None:
                    try:
                        from rapidocr_onnxruntime import RapidOCR
                        self.ocr = RapidOCR()
                    except ImportError as exc:
                        raise PDFExtractionError("OCR is required for this scanned page; install rapidocr-onnxruntime.") from exc
                pix = page.get_pixmap(dpi=150)
                try:
                    ocr_result, _ = self.ocr(pix.tobytes("png"))
                except (RuntimeError, OSError, ValueError) as exc:
                    raise PDFExtractionError(f"OCR failed on page {page_num}: {exc}") from exc
                if ocr_result:
                    scale = 72.0 / 150.0
                    for box, text, _score in ocr_result:
                        xs = [pt[0] for pt in box]
                        ys = [pt[1] for pt in box]
                        text_blocks.append({
                            "bbox": (min(xs) * scale, min(ys) * scale,
                                     max(xs) * scale, max(ys) * scale),
                            "text": text, "source": "ocr", "confidence": float(_score),
                        })
        if not text_blocks:
            raise PDFExtractionError(f"No text could be extracted from PDF page {page_num}.")
        return {"page_rect": page_rect, "text_blocks": text_blocks}

    def render_page(self, pdf_path: str, page_num: int, output_path: str,
                    dpi: int = 300) -> str:
        """Render a PDF page to a high-resolution PNG for vision review."""
        if dpi < 72 or dpi > 1200:
            raise ValueError("Render DPI must be between 72 and 1200.")
        try:
            with fitz.open(pdf_path) as doc:
                if doc.is_encrypted and not doc.authenticate(""):
                    raise PDFExtractionError("Encrypted PDF requires a password and is unsupported.")
                if page_num < 0 or page_num >= len(doc):
                    raise PDFExtractionError(f"Page index {page_num} is outside the PDF page range.")
                page = doc.load_page(page_num)
                target = Path(output_path)
                target.parent.mkdir(parents=True, exist_ok=True)
                page.get_pixmap(dpi=dpi, alpha=False).save(str(target))
                return str(target)
        except (RuntimeError, OSError) as exc:
            raise PDFExtractionError(f"Could not render PDF page {page_num}: {exc}") from exc
