"""Recognize view labels where they are explicitly printed in extracted text."""
import re

from gdt_validator.models.drawing_ir import DrawingView


def extract_view_labels(text_blocks: list[dict], page: int = 1) -> list[DrawingView]:
    views = []
    patterns = [
        ("SECTION", re.compile(r"(?i)\bSECTION\s+([A-Z](?:\s*[-–]\s*[A-Z])?)")),
        ("DETAIL", re.compile(r"(?i)\bDETAIL\s+([A-Z0-9]+)")),
        ("ISOMETRIC", re.compile(r"(?i)\b(ISOMETRIC|ISOMETRIC VIEW)\b")),
        ("FRONT", re.compile(r"(?i)\bFRONT VIEW\b")),
        ("TOP", re.compile(r"(?i)\bTOP VIEW\b")),
        ("BOTTOM", re.compile(r"(?i)\bBOTTOM VIEW\b")),
        ("LEFT", re.compile(r"(?i)\bLEFT VIEW\b")),
        ("RIGHT", re.compile(r"(?i)\bRIGHT VIEW\b")),
        ("REAR", re.compile(r"(?i)\bREAR VIEW\b")),
    ]
    seen = set()
    for block_no, block in enumerate(text_blocks):
        text = str(block.get("text", ""))
        for kind, pattern in patterns:
            match = pattern.search(text)
            if not match:
                continue
            label = match.group(1) if kind in {"SECTION", "DETAIL"} else None
            key = (kind, label)
            if key in seen:
                continue
            seen.add(key)
            views.append(DrawingView(
                id=f"view_p{page}_{len(views) + 1:03d}", type=kind, label=label,
                page=page, bbox=list(block.get("bbox") or [0, 0, 0, 0]),
                confidence=0.65, source="pdf_text_label"))
    return views
