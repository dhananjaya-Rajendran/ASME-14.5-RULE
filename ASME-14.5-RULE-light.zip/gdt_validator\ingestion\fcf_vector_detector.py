from pathlib import Path
from typing import Dict, List, Tuple

import cv2
import pymupdf as fitz
import numpy as np


class VectorFCFDetector:
    def __init__(self, detect_dpi: int = 200, crop_dpi: int = 250,
                 min_height_pt: float = 4.5, max_height_pt: float = 28.0,
                 min_ar: float = 1.8, max_ar: float = 14.0):
        self.detect_dpi = detect_dpi
        self.crop_dpi = crop_dpi
        self.scale = detect_dpi / 72.0
        self.min_h_px = int(min_height_pt * self.scale)
        self.max_h_px = int(max_height_pt * self.scale)
        self.min_ar = min_ar
        self.max_ar = max_ar

    def _render_page_to_gray(self, page: fitz.Page) -> np.ndarray:
        pix = page.get_pixmap(dpi=self.detect_dpi, colorspace=fitz.csGRAY)
        return np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width)

    @staticmethod
    def _has_fcf_compartments(binary_inv: np.ndarray, x: int, y: int,
                              w: int, h: int) -> Tuple[bool, int]:
        roi = binary_inv[y:y + h, x:x + w]
        if roi.size == 0:
            return False, 0
        fill_ratio = np.count_nonzero(roi) / float(w * h)
        if not 0.08 <= fill_ratio <= 0.65:
            return False, 0
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(3, int(h * 0.75))))
        v_lines = cv2.morphologyEx(roi, cv2.MORPH_OPEN, kernel)
        col_sums = (v_lines > 0).sum(axis=0)
        divider_cols = [c for c in np.where(col_sums >= int(h * 0.65))[0]
                        if int(w * 0.12) <= c <= int(w * 0.92)]
        if not divider_cols:
            return False, 0
        dividers = [divider_cols[0]]
        for col in divider_cols[1:]:
            if col - dividers[-1] > max(4, int(h * 0.25)):
                dividers.append(col)
        return True, len(dividers) + 1

    def extract_fcf_rois(self, pdf_path: str, page_num: int = 0,
                         out_dir: str = "fcf_crops", padding_pt: float = 18.0) -> List[Dict]:
        out_path = Path(out_dir)
        out_path.mkdir(parents=True, exist_ok=True)
        manifest: List[Dict] = []
        with fitz.open(pdf_path) as doc:
            page = doc[page_num]
            gray = self._render_page_to_gray(page)
            _, binary_inv = cv2.threshold(gray, 210, 255, cv2.THRESH_BINARY_INV)
            h_kernel = cv2.getStructuringElement(
                cv2.MORPH_RECT, (max(12, int(self.min_h_px * 1.5)), 1))
            v_kernel = cv2.getStructuringElement(
                cv2.MORPH_RECT, (1, max(8, int(self.min_h_px * 0.7))))
            grid_mask = cv2.bitwise_or(
                cv2.morphologyEx(binary_inv, cv2.MORPH_OPEN, h_kernel),
                cv2.morphologyEx(binary_inv, cv2.MORPH_OPEN, v_kernel))
            grid_mask = cv2.morphologyEx(
                grid_mask, cv2.MORPH_CLOSE,
                cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))
            contours, _ = cv2.findContours(grid_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            candidates = []
            for cnt in contours:
                x, y, w, h = cv2.boundingRect(cnt)
                if not self.min_h_px <= h <= self.max_h_px:
                    continue
                if not self.min_ar <= (w / float(h)) <= self.max_ar:
                    continue
                is_fcf, compartments = self._has_fcf_compartments(binary_inv, x, y, w, h)
                if is_fcf:
                    candidates.append((x, y, w, h, compartments))
            candidates.sort(key=lambda item: (item[1], item[0]))
            for idx, (x, y, w, h, compartments) in enumerate(candidates):
                bbox = [round(x / self.scale, 2), round(y / self.scale, 2),
                        round((x + w) / self.scale, 2), round((y + h) / self.scale, 2)]
                rect = fitz.Rect(max(0, bbox[0] - padding_pt), max(0, bbox[1] - padding_pt),
                                 min(page.rect.width, bbox[2] + padding_pt),
                                 min(page.rect.height, bbox[3] + padding_pt))
                crop_file = out_path / f"vector_fcf_{idx:03d}.png"
                page.get_pixmap(clip=rect, dpi=self.crop_dpi).save(str(crop_file))
                manifest.append({
                    "roi_id": f"VEC_FCF_{idx:03d}", "bbox": bbox,
                    "compartments_detected": compartments,
                    "image_path": str(crop_file),
                    "raw_pdf_text": page.get_text("text", clip=rect).strip(),
                })
        return manifest
