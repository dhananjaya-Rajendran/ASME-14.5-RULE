from pathlib import Path
import re
from typing import Dict, List, Optional

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from gdt_validator.schemas import (DrawingExtraction, RuleExplanation,
                                   ValidationResult, ValidationViolation)


class EngineeringReportBuilder:
    def __init__(self, output_pdf_path: str):
        self.output_pdf_path = Path(output_pdf_path)
        self.output_pdf_path.parent.mkdir(parents=True, exist_ok=True)
        self.styles = getSampleStyleSheet()

    def generate_report(self, drawing: DrawingExtraction,
                        violations: List[ValidationViolation],
                        roi_image_map: Optional[Dict[str, str]] = None,
                        source_pdf_path: Optional[str] = None,
                        llm_narrative: Optional[Dict[str, str]] = None,
                        explanations: Optional[List[RuleExplanation]] = None,
                        validation_result: Optional[ValidationResult] = None) -> str:
        doc = SimpleDocTemplate(
            str(self.output_pdf_path), pagesize=landscape(A4),
            leftMargin=12 * mm, rightMargin=12 * mm,
            topMargin=14 * mm, bottomMargin=14 * mm)
        story = [Paragraph(f"{drawing.applicable_standard} Validation Report", self.styles["Heading1"]),
                 Paragraph(f"Drawing: {drawing.drawing_id}", self.styles["Normal"]),
                 Spacer(1, 5 * mm)]
        completeness = getattr(drawing, "completeness", None)
        if completeness is not None:
            missing = ", ".join(completeness.missing_components) or "none"
            report_status = (validation_result.status if validation_result is not None else
                             "FAIL" if any(item.status == "FAIL" for item in violations)
                             else "REVIEW_REQUIRED" if completeness.status == "REVIEW_REQUIRED" or
                             any(item.status == "REVIEW_REQUIRED" for item in violations)
                             else "WARNING" if violations else "PASS")
            story.append(Paragraph(
                f"Overall drawing status: <b>{report_status}</b>; extraction stages requiring review: {missing}. "
                "An incomplete extraction cannot produce a compliance pass.",
                self.styles["Normal"]))
            story.append(Paragraph(
                "IR counts — dimensions: " + str(len(getattr(drawing, "dimensions", []))) +
                "; tolerances: " + str(len(getattr(drawing, "tolerances", []))) +
                "; views: " + str(len(getattr(drawing, "views", []))) +
                "; features: " + str(len(getattr(drawing, "features", []))) +
                "; holes: " + str(len(getattr(drawing, "holes", []))) +
                "; patterns: " + str(len(getattr(drawing, "patterns", []))) +
                "; notes: " + str(len(getattr(drawing, "notes", []))) +
                "; relations: " + str(len(getattr(drawing, "relations", []))) + ".",
                self.styles["Normal"]))
        story.append(Paragraph("Rule-engine summary", self.styles["Heading2"]))
        story.append(Paragraph(
            f"The deterministic ASME rule engine evaluated {len(drawing.feature_control_frames)} "
            f"feature control frame(s) and identified {len(violations)} finding(s). "
            "Only the findings listed below are rule outcomes. A clean result means no "
            "issue was detected by the implemented checks; it does not establish full compliance.",
            self.styles["Normal"]))
        story.append(Spacer(1, 3 * mm))
        story.append(Paragraph("Extracted FCF data", self.styles["Heading2"]))
        fcf_rows = [["FCF ID", "Characteristic", "Tolerance", "Zone", "Modifier", "Datums", "Feature link"]]
        for frame in drawing.feature_control_frames:
            datums = ", ".join(
                f"{datum.datum_letter} ({getattr(datum.material_condition, 'value', datum.material_condition)})"
                for datum in frame.datums) or "None extracted"
            fcf_rows.append([
                Paragraph(frame.id, self.styles["Normal"]),
                Paragraph(frame.characteristic_symbol, self.styles["Normal"]),
                Paragraph(str(frame.tolerance_value) if frame.tolerance_value is not None else "Unknown", self.styles["Normal"]),
                Paragraph("Diameter" if frame.diameter_zone else "Cylindrical/other", self.styles["Normal"]),
                Paragraph(getattr(frame.material_condition, "value", frame.material_condition) or "Unknown", self.styles["Normal"]),
                Paragraph(datums, self.styles["Normal"]),
                Paragraph(frame.associated_feature_type, self.styles["Normal"]),
            ])
        if len(fcf_rows) == 1:
            fcf_rows.append([Paragraph("No FCFs extracted", self.styles["Normal"]), "", "", "", "", "", ""])
        fcf_table = Table(fcf_rows, colWidths=[22 * mm, 38 * mm, 22 * mm, 27 * mm, 22 * mm, 36 * mm, 28 * mm], repeatRows=1)
        fcf_table.setStyle(TableStyle([
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        story.extend([fcf_table, Spacer(1, 4 * mm)])
        story.extend([
            Paragraph("Automated findings", self.styles["Heading2"]),
            Paragraph("Rule outcomes are generated by the deterministic validator. "
                      "Retrieved standard text is supporting context and does not create findings.", self.styles["Normal"]),
            Spacer(1, 3 * mm),
        ])
        rows = [["Item ID", "Severity", "Finding", "ASME Clause", "Remediation"]]
        for violation in violations:
            source_pages = sorted(set(re.findall(
                r"\[Source page (\d+);", violation.knowledge_context or "")), key=int)
            clause_text = violation.asme_clause_reference
            if source_pages:
                clause_text += f"<br/>Knowledge base pages: {', '.join(source_pages)}"
            rows.append([
                Paragraph(violation.fcf_id, self.styles["Normal"]),
                Paragraph(violation.severity, self.styles["Normal"]),
                Paragraph(violation.description, self.styles["Normal"]),
                Paragraph(clause_text, self.styles["Normal"]),
                Paragraph(violation.remediation_action or "", self.styles["Normal"]),
            ])
        if len(rows) == 1:
            rows.append([Paragraph("—", self.styles["Normal"]), "", 
                         Paragraph("No rule violations detected.", self.styles["Normal"]), "", ""])
        table = Table(rows, colWidths=[25 * mm, 25 * mm, 70 * mm, 55 * mm, 75 * mm], repeatRows=1)
        table.setStyle(TableStyle([
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(table)
        if explanations:
            story.extend([Spacer(1, 5 * mm), Paragraph("Retrieved references and explanations", self.styles["Heading2"])])
            for item in explanations:
                story.append(Paragraph(
                    f"{item.rule_id}: {item.explanation_status}. {item.explanation}",
                    self.styles["Normal"]))
                for citation in item.citations:
                    story.append(Paragraph(
                        f"{citation.standard}, edition {citation.edition}, "
                        f"section {citation.section or 'unclassified'}, "
                        f"page {citation.page}, source {citation.source_id}: "
                        f"{citation.excerpt}", self.styles["Normal"]))
                if item.recommended_review:
                    story.append(Paragraph(f"Engineer review: {item.recommended_review}",
                                           self.styles["Italic"]))
        story.extend([Spacer(1, 5 * mm), Paragraph(
            "Scope: This is a limited automated review based on extracted PDF content and "
            "selected checks associated with the attached ASME Y14.5M-1994 edition. "
            "OCR and feature association may be incomplete; verify the drawing and "
            "applicable contractual standard edition with a qualified reviewer.",
            self.styles["Italic"])])
        doc.build(story)
        return str(self.output_pdf_path)
