"""OCR FCF crops and extract labeled entities with spaCy or Hugging Face NER."""

from __future__ import annotations

import re
from functools import lru_cache
from pathlib import Path
from typing import Any


DEFAULT_HF_NER_MODEL = "erickrribeiro/bert-finetuned-ner"

CHARACTERISTICS = {
    "flatness": "flatness", "straightness": "straightness",
    "circularity": "circularity", "roundness": "circularity",
    "cylindricity": "cylindricity", "perpendicularity": "perpendicularity",
    "perpendicular": "perpendicularity", "parallelism": "parallelism",
    "parallel": "parallelism", "angularity": "angularity",
    "position": "position", "true position": "position",
    "profile of a line": "profile_of_a_line", "line profile": "profile_of_a_line",
    "profile of a surface": "profile_of_a_surface", "surface profile": "profile_of_a_surface",
    "circular runout": "circular_runout", "total runout": "total_runout",
}

LABEL_ALIASES = {
    "CHARACTERISTIC": "CHARACTERISTIC", "CHARACTERISTIC_SYMBOL": "CHARACTERISTIC",
    "GDT_CHARACTERISTIC": "CHARACTERISTIC", "TOLERANCE_VALUE": "TOLERANCE_VALUE",
    "TOLERANCE": "TOLERANCE_VALUE", "DIAMETER": "DIAMETER",
    "DIAMETER_ZONE": "DIAMETER", "MATERIAL_CONDITION": "MATERIAL_CONDITION",
    "DATUM_REFERENCE": "DATUM_REFERENCE", "DATUM": "DATUM",
}


@lru_cache(maxsize=4)
def _load_spacy_model(model_path: str):
    try:
        import spacy
    except ImportError as exc:
        raise RuntimeError("spaCy is required to load a local spaCy NER model.") from exc
    return spacy.load(model_path)


@lru_cache(maxsize=4)
def _load_transformer_model(model_reference: str):
    """from_pretrained downloads the tokenizer/model on first use and caches them."""
    try:
        import tensorflow as tf
        from transformers import AutoTokenizer, TFAutoModelForTokenClassification
    except ImportError as exc:
        raise RuntimeError(
            "TensorFlow Transformers dependencies are missing. Install requirements.txt "
            "with the active interpreter (tensorflow, transformers, and tf-keras)."
        ) from exc
    tokenizer = AutoTokenizer.from_pretrained(model_reference, use_fast=True)
    try:
        model = TFAutoModelForTokenClassification.from_pretrained(model_reference)
    except (OSError, ValueError) as exc:
        raise RuntimeError(
            f"Could not load TensorFlow weights for {model_reference!r}. If this checkpoint only has "
            "pytorch_model.bin, convert it once with tools/convert_ner_to_tensorflow.py, then pass "
            "the converted local folder as --ner-model."
        ) from exc
    return tf, tokenizer, model


def _get_entities(text: str, model_reference: str) -> list[dict[str, Any]]:
    local = Path(model_reference).expanduser()
    if local.is_dir() and (local / "config.cfg").is_file():
        doc = _load_spacy_model(str(local.resolve()))(text)
        return [{"text": ent.text, "label": ent.label_, "start": ent.start_char,
                 "end": ent.end_char, "score": None} for ent in doc.ents]

    tf, tokenizer, model = _load_transformer_model(model_reference)
    encoded = tokenizer(text, return_tensors="tf", return_offsets_mapping=True,
                        truncation=True, max_length=512)
    offsets = encoded.pop("offset_mapping")[0].numpy().tolist()
    outputs = model(**encoded, training=False)
    logits = outputs.logits[0]
    probabilities = tf.nn.softmax(logits, axis=-1)
    ids = tf.argmax(logits, axis=-1).numpy().tolist()
    scores = tf.reduce_max(probabilities, axis=-1).numpy().tolist()

    entities = []
    active_label, active_start, active_end, active_scores = None, None, None, []

    def finish():
        if active_label is not None and active_start is not None and active_end is not None:
            entities.append({"text": text[active_start:active_end], "label": active_label,
                             "start": active_start, "end": active_end,
                             "score": sum(active_scores) / len(active_scores)})

    for token_id, (start, end), score in zip(ids, offsets, scores):
        if start == end:
            continue
        raw_label = str(model.config.id2label.get(token_id, "O"))
        if raw_label.upper() == "O":
            finish()
            active_label, active_start, active_end, active_scores = None, None, None, []
            continue
        prefix, sep, entity_type = raw_label.partition("-")
        label = (entity_type if sep else raw_label).upper()
        begins_entity = sep and prefix.upper() == "B"
        continues = (active_label == label and not begins_entity and
                     (not sep or prefix.upper() == "I"))
        if not continues:
            finish()
            active_label, active_start, active_end, active_scores = label, start, end, [score]
        else:
            active_end = end
            active_scores.append(score)
    finish()
    return entities


def _ocr_crop(image_path: str) -> str:
    try:
        from rapidocr_onnxruntime import RapidOCR
        import cv2
    except ImportError as exc:
        raise RuntimeError("Install rapidocr-onnxruntime and OpenCV to OCR FCF crops for NER.") from exc
    image = cv2.imread(image_path, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"Cannot read FCF crop: {image_path}")
    result, _ = RapidOCR()(image)
    return " ".join(str(item[1]) for item in (result or []) if len(item) > 1)


def _canonical_label(label: str) -> str:
    label = label.upper().replace("B-", "").replace("I-", "")
    return LABEL_ALIASES.get(label, label)


def _frame_fields(entities: list[dict[str, Any]], roi_id: str, bbox: list) -> dict[str, Any]:
    data: dict[str, Any] = {
        "id": roi_id, "bbox": bbox, "characteristic_symbol": "unknown",
        "tolerance_value": None, "diameter_zone": False,
        "material_condition": None, "datums": [],
        "associated_feature_type": "unknown", "is_feature_of_size": None,
        "has_size_tolerance_on_feature": None,
    }
    datum_entities = []
    for ent in entities:
        value = ent["text"].strip()
        normalized = re.sub(r"[_\-]+", " ", value.casefold()).strip()
        label = _canonical_label(ent["label"])
        if label == "CHARACTERISTIC":
            characteristic = CHARACTERISTICS.get(normalized)
            if characteristic:
                data["characteristic_symbol"] = characteristic
        elif label == "TOLERANCE_VALUE":
            number = re.search(r"\d+(?:\.\d+)?", value.replace(",", "."))
            if number and float(number.group()) > 0:
                data["tolerance_value"] = float(number.group())
        elif label == "DIAMETER":
            data["diameter_zone"] = True
        elif label == "MATERIAL_CONDITION":
            modifier = normalized.upper()
            if modifier in {"RFS", "MMC", "LMC"}:
                data["material_condition"] = modifier
        elif label in {"DATUM_REFERENCE", "DATUM"}:
            datum_entities.append((0 if label == "DATUM_REFERENCE" else 1, value))

    for _, value in sorted(datum_entities, key=lambda item: item[0]):
        for letter in re.findall(r"(?<![A-Za-z])([A-Z])(?![A-Za-z])", value.upper()):
            if letter not in {item["datum_letter"] for item in data["datums"]}:
                data["datums"].append({"datum_letter": letter, "material_condition": "RFS"})
    # Keep raw model entities visible in manual_review.json when generic labels
    # cannot be interpreted as GD&T fields.
    data["_ner_predictions"] = entities
    return data


def analyze_fcf_with_ner(image_path: str, raw_text: str, roi_id: str,
                         bbox: list, model_reference: str) -> dict[str, Any]:
    """OCR a crop, run the selected NER checkpoint, and map GD&T-tagged spans."""
    text = " ".join(part for part in (raw_text.strip(), _ocr_crop(image_path)) if part)
    entities = _get_entities(text, model_reference)
    return _frame_fields(entities, roi_id, bbox)


def resolve_declared_datums_with_ner(datum_manifest: list[dict],
                                     model_reference: str) -> list[str]:
    """Read detected datum feature symbols with the selected OCR+NER model."""
    letters = set()
    for item in datum_manifest:
        text = (item.get("embedded_text") or "").strip()
        if not text:
            text = _ocr_crop(item["image_path"])
        for ent in _get_entities(text, model_reference):
            if _canonical_label(ent["label"]) in {"DATUM", "DATUM_REFERENCE"}:
                value = ent["text"].strip().upper()
                if len(value) == 1 and value.isalpha():
                    letters.add(value)
    return sorted(letters)
