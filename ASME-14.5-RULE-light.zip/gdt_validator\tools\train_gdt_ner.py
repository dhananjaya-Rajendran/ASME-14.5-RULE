"""Train and run a spaCy NER model on manually annotated GD&T text.

Examples:
  python -m gdt_validator.tools.train_gdt_ner train --data gdt_validator/data/gdt_ner.jsonl --out gdt_validator/models/gdt_ner
  python -m gdt_validator.tools.train_gdt_ner predict --model gdt_validator/models/gdt_ner --text "POSITION ⌀0.25 M A B"

Training requires spaCy: pip install spacy. Annotation JSONL records contain text and
entities [{"start": 0, "end": 8, "label": "CHARACTERISTIC"}].
"""
import argparse
import json
import random
from pathlib import Path

try:
    from spacy.training import Example
except ImportError:
    Example = None


def read_records(path):
    records=[]
    for line_no,line in enumerate(Path(path).read_text(encoding="utf-8").splitlines(),1):
        if not line.strip(): continue
        row=json.loads(line); text=row.get("text"); entities=row.get("entities",[])
        if not isinstance(text,str): raise ValueError(f"Line {line_no}: missing text")
        spans=[]
        for ent in entities:
            start,end,label=ent.get("start"),ent.get("end"),ent.get("label")
            if not isinstance(start,int) or not isinstance(end,int) or not isinstance(label,str):
                raise ValueError(f"Line {line_no}: malformed entity {ent!r}")
            if not 0 <= start < end <= len(text): raise ValueError(f"Line {line_no}: invalid span {ent!r}")
            spans.append((start,end,label))
        spans.sort()
        for left,right in zip(spans,spans[1:]):
            if left[1] > right[0]: raise ValueError(f"Line {line_no}: overlapping entities {left} and {right}")
        records.append((text,spans))
    if not records: raise ValueError("No annotations found. Annotate text first.")
    return records


def train(args):
    spacy = load_spacy()
    if Example is None:
        raise SystemExit("The active Python environment does not have spaCy. Install it with: python -m pip install 'spacy>=3.7.0'")
    rows=read_records(args.data)
    nlp=spacy.blank("en")
    ner=nlp.add_pipe("ner")
    for _,spans in rows:
        for _,_,label in spans: ner.add_label(label)
    optimizer=nlp.initialize()
    random.seed(args.seed)
    for epoch in range(args.epochs):
        random.shuffle(rows); losses={}
        for text,spans in rows:
            doc=nlp.make_doc(text)
            example=Example.from_dict(doc,{"entities":spans})
            nlp.update([example],sgd=optimizer,drop=args.dropout,losses=losses)
        print(f"epoch {epoch+1}/{args.epochs}: {losses}")
    out=Path(args.out).expanduser().resolve(); out.mkdir(parents=True,exist_ok=True); nlp.to_disk(out)
    print(f"Saved NER model: {out}")


def predict(args):
    spacy = load_spacy()
    nlp=spacy.load(args.model)
    doc=nlp(args.text)
    for ent in doc.ents:
        print(json.dumps({"text":ent.text,"label":ent.label_,"start":ent.start_char,"end":ent.end_char},ensure_ascii=False))


def load_spacy():
    try:
        import spacy
        return spacy
    except ImportError as exc:
        raise SystemExit(
            f"spaCy is missing from this Python interpreter ({Path(__import__('sys').executable)}). "
            "Install it into this environment with: python -m pip install 'spacy>=3.7.0'"
        ) from exc


def main():
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest="command",required=True)
    t=sub.add_parser("train"); t.add_argument("--data",required=True); t.add_argument("--out",required=True)
    t.add_argument("--epochs",type=int,default=50); t.add_argument("--dropout",type=float,default=0.2); t.add_argument("--seed",type=int,default=42); t.set_defaults(func=train)
    q=sub.add_parser("predict"); q.add_argument("--model",required=True); q.add_argument("--text",required=True); q.set_defaults(func=predict)
    args=p.parse_args(); args.func(args)


if __name__=="__main__": main()
