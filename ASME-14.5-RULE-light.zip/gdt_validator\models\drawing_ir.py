"""Traceable drawing intermediate representation assembled by extraction stages."""
from typing import Any, Literal

from pydantic import BaseModel, Field

from gdt_validator.schemas import (DatumFeature, DimensionItem, DrawingData,
                                   DrawingNote, DrawingPage, FeatureControlFrame)


class Evidence(BaseModel):
    source: Literal["pdf_text", "ocr", "vision", "manual", "fused", "unknown"] = "unknown"
    page: int | None = None
    bbox: list[float] | None = None
    source_text: str | None = None
    confidence: float = Field(default=0.0, ge=0, le=1)


class DrawingMetadata(BaseModel):
    drawing_number: str | None = None
    part_number: str | None = None
    title: str | None = None
    revision: str | None = None
    sheet_number: int | None = None
    sheet_count: int | None = None
    units: Literal["MM", "IN", "UNKNOWN"] = "UNKNOWN"
    projection_method: str | None = None
    scale: str | None = None
    drawing_standard: str | None = None
    release_status: str | None = None
    evidence: list[Evidence] = Field(default_factory=list)


class DrawingTolerance(BaseModel):
    id: str
    dimension_id: str | None = None
    type: Literal["BILATERAL", "UNILATERAL", "LIMITS", "GENERAL", "UNKNOWN"]
    upper: float | None = None
    lower: float | None = None
    source_text: str | None = None
    evidence: Evidence = Field(default_factory=Evidence)


class DrawingView(BaseModel):
    id: str
    type: Literal["FRONT", "TOP", "BOTTOM", "LEFT", "RIGHT", "REAR", "ISOMETRIC",
                  "SECTION", "DETAIL", "AUXILIARY", "BROKEN", "UNKNOWN"] = "UNKNOWN"
    label: str | None = None
    page: int
    bbox: list[float] | None = None
    scale: str | None = None
    confidence: float = Field(default=0.0, ge=0, le=1)
    source: str = "unknown"


class MechanicalFeature(BaseModel):
    id: str
    type: Literal["HOLE", "SLOT", "POCKET", "STEP", "BOSS", "CYLINDER", "PLANE",
                  "CHAMFER", "FILLET", "THREAD", "COUNTERBORE", "COUNTERSINK",
                  "KEYWAY", "GROOVE", "PATTERN", "SURFACE", "EDGE", "AXIS", "UNKNOWN"] = "UNKNOWN"
    view_id: str | None = None
    geometry: dict[str, Any] = Field(default_factory=dict)
    dimensions: list[str] = Field(default_factory=list)
    gdts: list[str] = Field(default_factory=list)
    datums: list[str] = Field(default_factory=list)
    page: int | None = None
    bbox: list[float] | None = None
    confidence: float = Field(default=0.0, ge=0, le=1)
    evidence: Evidence = Field(default_factory=Evidence)


class HoleFeature(BaseModel):
    id: str
    diameter: float | None = None
    quantity: int | None = None
    depth: float | None = None
    termination: Literal["THRU", "BLIND", "UNKNOWN"] = "UNKNOWN"
    thread: str | None = None
    pattern_id: str | None = None
    feature_id: str | None = None
    page: int | None = None
    bbox: list[float] | None = None
    source_text: str
    confidence: float = Field(default=0.0, ge=0, le=1)


class FeaturePattern(BaseModel):
    id: str
    type: Literal["LINEAR", "CIRCULAR", "RECTANGULAR", "POLAR", "SYMMETRIC", "UNKNOWN"] = "UNKNOWN"
    quantity: int | None = None
    pitch: float | None = None
    pcd: float | None = None
    angular_spacing: float | None = None
    feature_ids: list[str] = Field(default_factory=list)
    evidence: Evidence = Field(default_factory=Evidence)


class SurfaceFinish(BaseModel):
    id: str
    roughness: float | None = None
    unit: str | None = None
    parameter: str | None = None
    feature_id: str | None = None
    evidence: Evidence = Field(default_factory=Evidence)


class MaterialInfo(BaseModel):
    material: str | None = None
    grade: str | None = None
    heat_treatment: str | None = None
    hardness: str | None = None
    coating: str | None = None
    evidence: list[Evidence] = Field(default_factory=list)


class GeneralTolerance(BaseModel):
    id: str
    specification: str | None = None
    source: Literal["TITLE_BLOCK", "NOTE", "UNKNOWN"] = "UNKNOWN"
    raw_text: str
    evidence: Evidence = Field(default_factory=Evidence)


class DrawingRelation(BaseModel):
    source: str
    relation: Literal["APPLIES_TO", "DEFINED_IN", "BELONGS_TO", "DATUM_FOR", "MEMBER_OF", "UNKNOWN"]
    target: str
    confidence: float = Field(default=0.0, ge=0, le=1)
    evidence: Evidence = Field(default_factory=Evidence)


class ExtractionComponent(BaseModel):
    name: str
    status: Literal["EXTRACTED", "PARTIAL", "NOT_DETECTED", "NOT_IMPLEMENTED", "FAILED"]
    count: int = 0
    message: str | None = None


class ExtractionMetadata(BaseModel):
    source_file: str | None = None
    stages: list[ExtractionComponent] = Field(default_factory=list)
    confidence_threshold_accept: float = 0.90
    confidence_threshold_review: float = 0.70


class CompletenessResult(BaseModel):
    status: Literal["READY", "REVIEW_REQUIRED"] = "REVIEW_REQUIRED"
    missing_components: list[str] = Field(default_factory=list)
    message: str = "Extraction completeness has not been evaluated."


class DrawingIR(DrawingData):
    """Comprehensive IR; legacy FCF/dimension fields remain the rule-engine contract."""
    drawing_metadata: DrawingMetadata = Field(default_factory=DrawingMetadata)
    views: list[DrawingView] = Field(default_factory=list)
    features: list[MechanicalFeature] = Field(default_factory=list)
    tolerances: list[DrawingTolerance] = Field(default_factory=list)
    holes: list[HoleFeature] = Field(default_factory=list)
    patterns: list[FeaturePattern] = Field(default_factory=list)
    surface_finishes: list[SurfaceFinish] = Field(default_factory=list)
    materials: list[MaterialInfo] = Field(default_factory=list)
    general_tolerances: list[GeneralTolerance] = Field(default_factory=list)
    relations: list[DrawingRelation] = Field(default_factory=list)
    extraction_metadata: ExtractionMetadata = Field(default_factory=ExtractionMetadata)
    completeness: CompletenessResult = Field(default_factory=CompletenessResult)

    @property
    def gdts(self) -> list[FeatureControlFrame]:
        """Explicit IR alias for the established FCF collection."""
        return self.feature_control_frames

    @property
    def drawing_pages(self) -> list[DrawingPage]:
        return self.pages

    @property
    def datum_features(self) -> list[DatumFeature]:
        return self.datums

    @property
    def drawing_notes(self) -> list[DrawingNote]:
        return self.notes

    @property
    def title_block(self) -> DrawingMetadata:
        """Explicit title-block alias; values retain their source evidence."""
        return self.drawing_metadata

    @property
    def sheets(self) -> list[DrawingPage]:
        return self.pages
