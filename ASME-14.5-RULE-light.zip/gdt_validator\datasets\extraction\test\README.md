Held-out extraction test split reserved for authorized, human-reviewed labels. Do not tune prompts against this set.
