"""Optional Transformers + PEFT inference backend for Qwen2.5-VL."""
from pathlib import Path
from typing import Any

from gdt_validator.vision.model_config import ModelConfig, verify_adapter_compatibility


class TransformersVLMClient:
    def __init__(self, config: ModelConfig):
        config.validate()
        if config.backend != "transformers":
            raise ValueError("TransformersVLMClient requires VLM_BACKEND=transformers")
        self.config = config
        self.processor = None
        self.model = None

    def load(self) -> None:
        try:
            import torch
            from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration
        except ImportError as exc:
            raise RuntimeError(
                "Transformers inference requires compatible torch and transformers. "
                "Install the optional VLM dependencies."
            ) from exc
        if self.config.adapter_path:
            verify_adapter_compatibility(self.config.production_model, self.config.adapter_path)
            try:
                from peft import PeftModel
            except ImportError as exc:
                raise RuntimeError("Loading the configured LoRA adapter requires peft.") from exc
        self.processor = AutoProcessor.from_pretrained(self.config.production_model)
        model_kwargs: dict[str, Any] = {"device_map": self.config.device}
        if self.config.quantization:
            if self.config.quantization != "4bit":
                raise ValueError("Supported VLM_QUANTIZATION value is currently only '4bit'.")
            try:
                from transformers import BitsAndBytesConfig
            except ImportError as exc:
                raise RuntimeError("4bit inference requires bitsandbytes support.") from exc
            model_kwargs["quantization_config"] = BitsAndBytesConfig(load_in_4bit=True)
        model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
            self.config.production_model, **model_kwargs)
        if self.config.adapter_path:
            model = PeftModel.from_pretrained(model, str(Path(self.config.adapter_path).expanduser()))
        self.model = model.eval()

    def analyze_drawing(self, image: Any, prompt: str) -> dict:
        if self.model is None or self.processor is None:
            self.load()
        try:
            from PIL import Image
            image_obj = Image.open(image).convert("RGB") if isinstance(image, (str, Path)) else image
            messages = [{"role": "user", "content": [
                {"type": "image", "image": image_obj}, {"type": "text", "text": prompt}]}]
            text = self.processor.apply_chat_template(messages, tokenize=False,
                                                       add_generation_prompt=True)
            inputs = self.processor(text=[text], images=[image_obj], return_tensors="pt")
            device = self.model.device
            inputs = {key: value.to(device) if hasattr(value, "to") else value
                      for key, value in inputs.items()}
            output = self.model.generate(**inputs, max_new_tokens=self.config.max_tokens,
                                         do_sample=self.config.temperature > 0,
                                         temperature=max(self.config.temperature, 1e-5))
            generated = output[:, inputs["input_ids"].shape[1]:]
            content = self.processor.batch_decode(generated, skip_special_tokens=True,
                                                   clean_up_tokenization_spaces=False)[0]
        except (OSError, ValueError, RuntimeError, KeyError, IndexError) as exc:
            raise RuntimeError(f"Transformers VLM inference failed: {exc}") from exc
        import json
        try:
            payload = json.loads(content)
        except json.JSONDecodeError as exc:
            raise ValueError("Transformers VLM returned malformed JSON.") from exc
        if not isinstance(payload, dict):
            raise ValueError("VLM response must be a JSON object.")
        return payload
