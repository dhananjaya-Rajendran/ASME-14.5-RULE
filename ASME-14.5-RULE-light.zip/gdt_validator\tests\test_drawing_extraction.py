import pymupdf

from gdt_validator.extraction.drawing_extractor import extract_drawing_ir
from gdt_validator.schemas import FeatureControlFrame
from gdt_validator.validation.asme_rule_engine import ASMEY145RuleEngine
from gdt_validator.extraction.dimension_extractor import extract_dimensions


def test_pdf_to_partial_drawing_ir_retains_evidence_and_fails_completeness_closed(tmp_path):
    pdf_path = tmp_path / "drawing.pdf"
    document = pymupdf.open()
    page = document.new_page(width=600, height=800)
    lines = ["DIA 20 +/-0.02", "4X DIA 6 THRU", "Ra 1.6",
             "BREAK SHARP EDGES", "DWG NO: D-001 REV: B", "SECTION A-A"]
    for index, line in enumerate(lines):
        page.insert_text((40, 40 + index * 24), line)
    document.save(pdf_path)
    document.close()

    frame = FeatureControlFrame(id="fcf_1", bbox=[10, 10, 30, 20],
        characteristic_symbol="flatness", tolerance_value=0.1,
        material_condition="RFS", confidence=1.0, source="manual")
    ir = extract_drawing_ir(str(pdf_path), feature_control_frames=[frame],
                            declared_datums=["A"], render_dir=str(tmp_path / "rendered"))

    assert ir.dimensions
    assert any(item.dimension_type == "DIAMETER" and item.nominal == 20 for item in ir.dimensions)
    assert ir.holes and ir.holes[0].quantity == 4
    assert ir.surface_finishes and ir.surface_finishes[0].roughness == 1.6
    assert ir.drawing_metadata.drawing_number == "D-001"
    assert ir.views and ir.views[0].type == "SECTION"
    assert (tmp_path / "rendered" / "page_001.png").is_file()
    assert ir.completeness.status == "REVIEW_REQUIRED"
    assert "features" in ir.completeness.missing_components
    findings = ASMEY145RuleEngine().validate(ir)
    assert all(item.status == "REVIEW_REQUIRED" for item in findings)


def test_dimension_normalization_recognizes_supported_annotation_forms():
    blocks = [
        {"text": "\u00d820\u00b10.02", "bbox": [1, 2, 3, 4], "source": "pdf_text"},
        {"text": "25+0.05/-0.01", "bbox": [2, 3, 4, 5], "source": "pdf_text"},
        {"text": "(30)", "bbox": [3, 4, 5, 6], "source": "pdf_text"},
        {"text": "\u25a125", "bbox": [4, 5, 6, 7], "source": "pdf_text"},
        {"text": "2x45\u00b0", "bbox": [5, 6, 7, 8], "source": "pdf_text"},
        {"text": "M10x1.5", "bbox": [6, 7, 8, 9], "source": "pdf_text"},
        {"text": "DEPTH 12", "bbox": [7, 8, 9, 10], "source": "pdf_text"},
    ]
    dims, tolerances = extract_dimensions(blocks)
    assert [item.dimension_type for item in dims] == [
        "DIAMETER", "LINEAR", "LINEAR", "LINEAR", "CHAMFER", "THREAD", "DEPTH"]
    assert dims[0].upper_tol == 0.02 and dims[0].lower_tol == -0.02
    assert dims[1].upper_tol == 0.05 and dims[1].lower_tol == -0.01
    assert dims[2].is_reference and dims[3].is_basic
    assert len(tolerances) == 2
