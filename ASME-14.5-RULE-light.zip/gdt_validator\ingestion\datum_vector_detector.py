from pathlib import Path
from typing import Dict, List

import cv2
import pymupdf as fitz
import numpy as np
from PIL import Image, ImageDraw


class VectorDatumDetector:
    def __init__(self, detect_dpi: int = 250, min_box_pt: float = 4.5,
                 max_box_pt: float = 26.0):
        self.detect_dpi = detect_dpi
        self.scale = detect_dpi / 72.0
        self.min_px = int(min_box_pt * self.scale)
        self.max_px = int(max_box_pt * self.scale)

    def detect_datum_symbols(self, pdf_path: str, page_num: int = 0,
                             out_dir: str = "datum_crops") -> List[Dict]:
        out_path = Path(out_dir)
        out_path.mkdir(parents=True, exist_ok=True)
        manifest: List[Dict] = []
        with fitz.open(pdf_path) as doc:
            page = doc[page_num]
            pix = page.get_pixmap(dpi=self.detect_dpi, colorspace=fitz.csGRAY)
            gray = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width)
            _, binary_inv = cv2.threshold(gray, 210, 255, cv2.THRESH_BINARY_INV)
            box_mask = cv2.bitwise_or(
                cv2.morphologyEx(binary_inv, cv2.MORPH_OPEN,
                                 cv2.getStructuringElement(cv2.MORPH_RECT, (6, 1))),
                cv2.morphologyEx(binary_inv, cv2.MORPH_OPEN,
                                 cv2.getStructuringElement(cv2.MORPH_RECT, (1, 6))))
            contours, _ = cv2.findContours(box_mask, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
            boxes = []
            for cnt in contours:
                x, y, w, h = cv2.boundingRect(cnt)
                if not (self.min_px <= h <= self.max_px and self.min_px <= w <= self.max_px):
                    continue
                if not 0.72 <= (w / float(h)) <= 1.45:
                    continue
                boxes.append((x, y, w, h))
            boxes.sort(key=lambda box: (box[1], box[0]))
            for idx, (x, y, w, h) in enumerate(boxes):
                rect = fitz.Rect(x / self.scale, y / self.scale,
                                 (x + w) / self.scale, (y + h) / self.scale)
                embedded = page.get_text("text", clip=rect).strip().replace("\n", "")
                crop_file = out_path / f"datum_box_{idx:02d}.png"
                page.get_pixmap(clip=rect, dpi=250).save(str(crop_file))
                manifest.append({
                    "datum_id": f"DATUM_{idx:02d}",
                    "box_bbox": [rect.x0, rect.y0, rect.x1, rect.y1],
                    "embedded_text": embedded if embedded else None,
                    "image_path": str(crop_file),
                })
        return manifest


def resolve_declared_datums(datum_manifest: List[Dict], out_dir: str = "datum_crops",
                            model: str | None = None) -> List[str]:
    letters = []
    unresolved = []
    for item in datum_manifest:
        text = item.get("embedded_text")
        if text and text.strip().isalpha() and len(text.strip()) == 1:
            letters.append(text.strip().upper())
        else:
            unresolved.append(item)
    if not unresolved:
        return sorted(set(letters))

    from gdt_validator.vision.model_config import ModelConfig
    from gdt_validator.vision.vlm_client import create_vlm_client
    config = ModelConfig.from_env()
    if model:
        config = ModelConfig(**{**config.__dict__, "ollama_model": model})
    if config.backend == "mock":
        # Unknown raster labels remain unknown during mock execution.
        return sorted(set(letters))

    output_dir = Path(out_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    sheet = Image.new("RGB", (80 * len(unresolved), 95), color="white")
    draw = ImageDraw.Draw(sheet)
    for idx, item in enumerate(unresolved):
        with Image.open(item["image_path"]) as source:
            crop = source.convert("RGB")
            crop.thumbnail((64, 64), Image.Resampling.LANCZOS)
            sheet.paste(crop, (idx * 80 + 8, 24))
        draw.text((idx * 80 + 32, 4), f"#{idx + 1}", fill=(200, 0, 0))
    sheet_path = output_dir / "datum_contact_sheet.png"
    sheet.save(sheet_path)

    from gdt_validator.vision.extraction_prompt import DATUM_EXTRACTION_PROMPT
    parsed = create_vlm_client(config).analyze_drawing(str(sheet_path), DATUM_EXTRACTION_PROMPT)
    values = parsed.get("datums")
    if not isinstance(values, list):
        raise ValueError("Datum extraction response must contain a datums array.")
    letters.extend(value.strip().upper() for value in values
                   if isinstance(value, str) and value.strip().isalpha() and len(value.strip()) == 1)
    return sorted(set(letters))
