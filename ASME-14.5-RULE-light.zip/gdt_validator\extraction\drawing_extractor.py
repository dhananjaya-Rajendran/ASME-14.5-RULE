"""PDF page to traceable, partial DrawingIR extraction pipeline."""
from pathlib import Path

from gdt_validator.extraction.completeness import check_extraction_completeness
from gdt_validator.extraction.dimension_extractor import extract_dimensions
from gdt_validator.extraction.hole_extractor import extract_hole_callouts
from gdt_validator.extraction.note_extractor import extract_notes
from gdt_validator.extraction.title_block_extractor import extract_title_block
from gdt_validator.extraction.view_extractor import extract_view_labels
from gdt_validator.ingestion.pdf_extractor import DrawingExtractor as PDFTextExtractor, PDFExtractionError
from gdt_validator.models.drawing_ir import (DrawingIR, DrawingPage, ExtractionComponent,
                                             ExtractionMetadata)


def extract_drawing_ir(pdf_path: str, page_num: int = 0, *, drawing_id: str | None = None,
                       declared_datums: list[str] | None = None,
                       feature_control_frames: list | None = None,
                       render_dir: str | None = None) -> DrawingIR:
    """Extract detectable text elements and retain explicit unsupported states.

    This version deliberately does not infer geometry, view extents, feature
    associations, or patterns from proximity. Such fields remain unsupported.
    """
    pdf_file = Path(pdf_path).expanduser().resolve()
    stages: list[ExtractionComponent] = []
    try:
        result = PDFTextExtractor().extract_text_and_rois(str(pdf_file), page_num=page_num)
        blocks = result["text_blocks"]
        page_rect = result["page_rect"]
        if render_dir:
            image_path = Path(render_dir) / f"page_{page_num + 1:03d}.png"
            image_path.parent.mkdir(parents=True, exist_ok=True)
            PDFTextExtractor().render_page(str(pdf_file), page_num, str(image_path), dpi=300)
        dimensions, tolerances = extract_dimensions(blocks, page=page_num + 1)
        notes, general_tolerances, materials, finishes = extract_notes(blocks, page=page_num + 1)
        if general_tolerances:
            for dimension in dimensions:
                if not dimension.is_basic and not dimension.is_reference:
                    dimension.covered_by_general_tolerance = True
        holes, patterns = extract_hole_callouts(blocks, page=page_num + 1)
        views = extract_view_labels(blocks, page=page_num + 1)
        metadata = extract_title_block(blocks, page=page_num + 1)
        stages.extend([
            ExtractionComponent(name="pdf_text_ocr", status="EXTRACTED", count=len(blocks)),
            ExtractionComponent(name="ocr_vlm_fusion", status="NOT_IMPLEMENTED",
                                message="OCR and VLM evidence are not yet reconciled field by field."),
            _state("dimensions", len(dimensions)),
            _state("tolerances", len(tolerances) + len(general_tolerances)),
            _state("general_tolerances", len(general_tolerances)),
            _state("views", len(views)),
            ExtractionComponent(name="features", status="NOT_IMPLEMENTED", message="Requires visual geometry detection."),
            _state("gdt_fcf", len(feature_control_frames or [])),
            _state("datums", len(declared_datums or [])),
            _state("holes", len(holes)),
            _state("patterns", len(patterns)),
            _state("surface_finishes", len(finishes)),
            _state("materials", len(materials)),
            _state("notes", len(notes)),
            ExtractionComponent(name="title_block", status="PARTIAL" if any(
                value is not None for key, value in metadata.model_dump().items()
                if key not in {"evidence", "units"}) else "NOT_DETECTED"),
            ExtractionComponent(name="relations", status="NOT_IMPLEMENTED", message="Feature association is not inferred from text proximity."),
            ExtractionComponent(name="feature_association", status="NOT_IMPLEMENTED", message="Text proximity is not treated as evidence of a feature relationship."),
        ])
        datums = []
        for letter in declared_datums or []:
            datums.append({"datum_letter": letter, "feature_type": "unknown",
                           "page": page_num + 1, "confidence": 0.0, "source": "unknown"})
        ir = DrawingIR(
            drawing_id=drawing_id or pdf_file.stem,
            declared_datums=declared_datums or [], dimensions=dimensions,
            feature_control_frames=feature_control_frames or [],
            pages=[DrawingPage(page=page_num + 1, width=float(page_rect[2] - page_rect[0]),
                               height=float(page_rect[3] - page_rect[1]), source="pdf")],
            datums=datums, notes=notes, drawing_metadata=metadata, views=views,
            features=[], tolerances=tolerances, holes=holes, patterns=patterns,
            surface_finishes=finishes, materials=materials, general_tolerances=general_tolerances,
            relations=[], extraction_metadata=ExtractionMetadata(
                source_file=pdf_file.name, stages=stages))
    except PDFExtractionError as exc:
        stages.append(ExtractionComponent(name="pdf_text_ocr", status="FAILED", message=str(exc)))
        ir = DrawingIR(drawing_id=drawing_id or pdf_file.stem,
            declared_datums=declared_datums or [],
            feature_control_frames=feature_control_frames or [],
            extraction_metadata=ExtractionMetadata(source_file=pdf_file.name, stages=stages))
    ir.completeness = check_extraction_completeness(ir)
    return ir


def _state(name: str, count: int) -> ExtractionComponent:
    return ExtractionComponent(name=name,
        status="PARTIAL" if count else "NOT_DETECTED", count=count,
        message="Text-based detection only; visual associations may be missing." if count else None)
