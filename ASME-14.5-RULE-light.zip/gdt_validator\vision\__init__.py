"""Vision model clients."""
