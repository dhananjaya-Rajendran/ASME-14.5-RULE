"""GD&T rule validation and explanation."""
