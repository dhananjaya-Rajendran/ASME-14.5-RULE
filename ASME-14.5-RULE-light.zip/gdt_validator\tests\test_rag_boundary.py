import pytest

from gdt_validator.schemas import RuleDecision
from gdt_validator.validation.rag_explainer import ASMERagExplainer
from gdt_validator.validation.rule_registry import RULE_REGISTRY


def test_rule_decisions_are_immutable_and_rag_returns_separate_explanations(tmp_path):
    decision = RuleDecision(rule_id="ASME-Y14.5-FORM-001", standard="ASME Y14.5",
        edition="M-1994", status="INSUFFICIENT_INFORMATION", message="Review extracted FCF.",
        reference_hint="Section 6.4", rule_confidence=0.9)
    with pytest.raises(Exception):
        decision.status = "FAIL"

    explanation = ASMERagExplainer(use_chroma=False,
        knowledge_base_path=str(tmp_path / "missing.sqlite3")).explain([decision])[0]
    assert explanation.rule_id == decision.rule_id
    assert explanation.explanation_status == "INSUFFICIENT_REFERENCE_EVIDENCE"
    assert explanation.citations == []
    assert decision.status == "INSUFFICIENT_INFORMATION"


def test_current_rules_are_not_claimed_expert_verified():
    assert RULE_REGISTRY
    assert all(rule.verification_status == "UNDER_REVIEW" for rule in RULE_REGISTRY.values())
    assert all(rule.edition == "M-1994" for rule in RULE_REGISTRY.values())
