"""Validation reports and PDF annotations."""
