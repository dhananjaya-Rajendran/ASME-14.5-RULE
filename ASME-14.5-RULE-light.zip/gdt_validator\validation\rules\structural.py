"""Pure rule functions for the currently supported drawing structure checks.

These checks are intentionally marked UNDER_REVIEW in the registry until an
authorized GD&T expert verifies them against the applicable licensed edition.
"""
from gdt_validator.schemas import DimensionItem, FeatureControlFrame, ValidationViolation
from gdt_validator.validation.rule_registry import RULE_REGISTRY

FORM = {"flatness", "straightness", "circularity", "cylindricity"}
DATUM_REQUIRED = {"perpendicularity", "parallelism", "angularity", "position",
                  "profile_of_a_line", "profile_of_a_surface", "circular_runout", "total_runout"}
KNOWN = FORM | DATUM_REQUIRED


def _finding(rule_id: str, standard: str, status: str, severity: str, target: str,
             bbox: list, message: str, clause: str, confidence: float,
             evidence: dict) -> ValidationViolation:
    metadata = RULE_REGISTRY.get(rule_id)
    if metadata is None or metadata.verification_status != "EXPERT_VERIFIED":
        status, severity = "REVIEW_REQUIRED", "WARNING"
        state = metadata.verification_status if metadata else "unregistered"
        message += f" Rule verification state is {state}; an engineer must review this candidate."
    return ValidationViolation(rule_id=rule_id, severity=severity, status=status,
        confidence=confidence, fcf_id=target, bbox=bbox, description=message,
        asme_clause_reference=f"{standard} {clause}", evidence=evidence)


def validate_dimension_tolerance(dim: DimensionItem, standard: str) -> ValidationViolation | None:
    excepted = (dim.is_basic or dim.is_reference or dim.is_maximum or dim.is_minimum
                or dim.is_stock_size or dim.covered_by_general_tolerance is True)
    if dim.has_tolerance is not False or excepted:
        return None
    return _finding("ASME-Y14.5-DIM-001", standard, "WARNING", "WARNING", dim.id, dim.bbox,
        "No explicit or general tolerance was identified; confirm applicable exceptions.",
        "Section 1.4", 0.8, {"bbox": dim.bbox, "nominal": dim.nominal,
        "page": dim.page, "source_text": dim.source_text})


def validate_fcf_tolerance(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    if fcf.tolerance_value is not None and fcf.tolerance_value > 0:
        return None
    return _finding("ASME-Y14.5-FCF-001", standard, "REVIEW_REQUIRED", "WARNING", fcf.id,
        fcf.bbox, "FCF tolerance is missing or non-positive; verify the source crop.",
        "FCF interpretation", 0.98, {"bbox": fcf.bbox, "page": fcf.page, "source_text": fcf.source_text})


def validate_fcf_characteristic(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    char = str(getattr(fcf.characteristic_symbol, "value", fcf.characteristic_symbol)).lower()
    if char in KNOWN:
        return None
    return _finding("ASME-Y14.5-FCF-002", standard, "REVIEW_REQUIRED", "WARNING", fcf.id,
        fcf.bbox, "FCF characteristic is unknown or unsupported in extracted data.",
        "FCF interpretation", 0.98, {"bbox": fcf.bbox, "page": fcf.page, "source_text": fcf.source_text})


def validate_form_datums(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    char = str(getattr(fcf.characteristic_symbol, "value", fcf.characteristic_symbol)).lower()
    if char not in FORM or not fcf.datums:
        return None
    return _finding("ASME-Y14.5-FORM-001", standard, "FAIL", "ERROR", fcf.id, fcf.bbox,
        f"{char.replace('_', ' ').title()} control contains datum references.",
        "Section 6.4", 0.9, {"bbox": fcf.bbox, "page": fcf.page, "source_text": fcf.source_text})


def validate_required_datums(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    char = str(getattr(fcf.characteristic_symbol, "value", fcf.characteristic_symbol)).lower()
    if char not in DATUM_REQUIRED or fcf.datums:
        return None
    return _finding("ASME-Y14.5-DATUM-001", standard, "REVIEW_REQUIRED", "WARNING", fcf.id, fcf.bbox,
        f"{char.replace('_', ' ').title()} has no extracted datum references; verify the drawing.",
        "datum reference framework", 0.9, {"bbox": fcf.bbox, "page": fcf.page})


def validate_datum_declaration(fcf: FeatureControlFrame, declared_datums: set[str],
                               standard: str) -> list[ValidationViolation]:
    output = []
    for datum in fcf.datums:
        letter = datum.datum_letter.strip().upper()
        if letter not in declared_datums:
            output.append(_finding("ASME-Y14.5-DATUM-002", standard, "WARNING", "WARNING", fcf.id,
                fcf.bbox, f"Referenced datum '{letter}' was not found by datum extraction; confirm visually.",
                "Section 4.3", 0.7, {"bbox": fcf.bbox, "datum": letter, "page": fcf.page}))
    return output


def validate_duplicate_datums(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    letters = [datum.datum_letter.strip().upper() for datum in fcf.datums]
    if len(set(letters)) == len(letters):
        return None
    return _finding("ASME-Y14.5-DATUM-003", standard, "FAIL", "ERROR", fcf.id, fcf.bbox,
        "FCF repeats a datum reference letter.", "datum reference sequence", 0.95,
        {"bbox": fcf.bbox, "datums": letters, "page": fcf.page})


def validate_datum_count(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    letters = [datum.datum_letter.strip().upper() for datum in fcf.datums]
    if len(letters) <= 3:
        return None
    return _finding("ASME-Y14.5-DATUM-004", standard, "FAIL", "ERROR", fcf.id, fcf.bbox,
        "FCF contains more than three datum references.", "datum reference framework", 0.9,
        {"bbox": fcf.bbox, "datums": letters, "page": fcf.page})


def validate_diameter_zone(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    char = str(getattr(fcf.characteristic_symbol, "value", fcf.characteristic_symbol)).lower()
    if not fcf.diameter_zone or char not in FORM:
        return None
    return _finding("ASME-Y14.5-ZONE-001", standard, "FAIL", "ERROR", fcf.id, fcf.bbox,
        "Diameter zone modifier is inconsistent with this form control.",
        "tolerance-zone interpretation", 0.95, {"bbox": fcf.bbox, "page": fcf.page})


def validate_modifier_feature_size(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    modifier = str(getattr(fcf.material_condition, "value", fcf.material_condition)).upper()
    size = fcf.is_feature_of_size
    if modifier not in {"MMC", "LMC"} or size is not False:
        return None
    return _finding("ASME-Y14.5-MOD-003", standard, "FAIL", "ERROR", fcf.id, fcf.bbox,
        f"{modifier} is applied to a control not associated with a feature of size.",
        "Section 2.8", 0.9, {"bbox": fcf.bbox, "modifier": modifier, "page": fcf.page})


def validate_modifier_feature_unknown(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    modifier = str(getattr(fcf.material_condition, "value", fcf.material_condition)).upper()
    size = fcf.is_feature_of_size
    if size is None and fcf.associated_feature_type in {"hole", "shaft"}:
        size = True
    if modifier not in {"MMC", "LMC"} or size is not None:
        return None
    return _finding("ASME-Y14.5-MOD-005", standard, "REVIEW_REQUIRED", "WARNING", fcf.id,
        fcf.bbox, f"Confirm that the {modifier} control applies to a feature of size.",
        "Section 2.8", 0.85, {"bbox": fcf.bbox, "modifier": modifier, "page": fcf.page})


def validate_modifier_form(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    char = str(getattr(fcf.characteristic_symbol, "value", fcf.characteristic_symbol)).lower()
    modifier = str(getattr(fcf.material_condition, "value", fcf.material_condition)).upper()
    if char not in FORM or modifier not in {"MMC", "LMC"}:
        return None
    return _finding("ASME-Y14.5-MOD-001", standard, "FAIL", "ERROR", fcf.id, fcf.bbox,
        f"{modifier} modifier is not applicable to this form tolerance.",
        "Section 2.8", 0.9, {"bbox": fcf.bbox, "modifier": modifier, "page": fcf.page})


def validate_modifier_size_tolerance(fcf: FeatureControlFrame, standard: str) -> ValidationViolation | None:
    modifier = str(getattr(fcf.material_condition, "value", fcf.material_condition)).upper()
    if modifier not in {"MMC", "LMC"} or fcf.has_size_tolerance_on_feature is not False:
        return None
    return _finding("ASME-Y14.5-MOD-004", standard, "WARNING", "WARNING", fcf.id, fcf.bbox,
        "No size tolerance was linked to the associated feature; confirm size limits.",
        "Sections 1.4 and 2.8", 0.8, {"bbox": fcf.bbox, "modifier": modifier, "page": fcf.page})


def validate_references(fcf: FeatureControlFrame, standard: str) -> list[ValidationViolation]:
    """Run independently named structural rules against one extracted FCF."""
    output = []
    for rule in (validate_fcf_tolerance, validate_fcf_characteristic, validate_form_datums,
                 validate_required_datums, validate_duplicate_datums, validate_datum_count,
                 validate_diameter_zone, validate_modifier_feature_size,
                 validate_modifier_feature_unknown, validate_modifier_form,
                 validate_modifier_size_tolerance):
        result = rule(fcf, standard)
        if result is not None:
            output.append(result)
    return output
