"""One-time conversion of a PyTorch HF token-classification checkpoint to TensorFlow.

Conversion needs both TensorFlow and PyTorch installed in the conversion environment.
Normal validation uses only the saved TensorFlow model.

Example:
  python -m gdt_validator.tools.convert_ner_to_tensorflow \
      --source erickrribeiro/bert-finetuned-ner \
      --out gdt_validator/models/bert-finetuned-ner-tf
"""

import argparse
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", default="erickrribeiro/bert-finetuned-ner",
                        help="Hugging Face model ID or local PyTorch checkpoint directory")
    parser.add_argument("--out", required=True, help="Output directory for TensorFlow weights")
    args = parser.parse_args()

    try:
        from transformers import AutoTokenizer, TFAutoModelForTokenClassification
    except ImportError as exc:
        raise SystemExit(
            "Install TensorFlow, PyTorch, and Transformers in this conversion environment. "
            "PyTorch is only used for this one-time weight conversion."
        ) from exc

    tokenizer = AutoTokenizer.from_pretrained(args.source, use_fast=True)
    model = TFAutoModelForTokenClassification.from_pretrained(args.source, from_pt=True)
    output = Path(args.out).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(output)
    tokenizer.save_pretrained(output)
    print(f"Saved TensorFlow NER checkpoint: {output}")


if __name__ == "__main__":
    main()
