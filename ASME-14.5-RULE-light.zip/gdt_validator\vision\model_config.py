"""Central model identity and backend configuration."""
from dataclasses import dataclass
import os
from pathlib import Path


DEFAULT_BASE_MODEL = "Qwen/Qwen2.5-VL-3B-Instruct"
DEFAULT_OLLAMA_MODEL = "qwen2.5vl:7b"


@dataclass(frozen=True)
class ModelConfig:
    training_model: str = DEFAULT_BASE_MODEL
    production_model: str = DEFAULT_BASE_MODEL
    adapter_path: str | None = None
    backend: str = "ollama"
    ollama_model: str = DEFAULT_OLLAMA_MODEL
    device: str = "auto"
    quantization: str | None = None
    max_tokens: int = 512
    temperature: float = 0.0

    @classmethod
    def from_env(cls) -> "ModelConfig":
        backend = os.getenv("VLM_BACKEND", "ollama").strip().lower()
        if os.getenv("MOCK_MODE", "false").strip().lower() in {"1", "true", "yes", "on"}:
            backend = "mock"
        return cls(
            training_model=os.getenv("TRAINING_MODEL", DEFAULT_BASE_MODEL),
            production_model=os.getenv("VLM_BASE_MODEL", DEFAULT_BASE_MODEL),
            adapter_path=os.getenv("VLM_ADAPTER_PATH") or None,
            backend=backend,
            ollama_model=os.getenv("OLLAMA_MODEL", DEFAULT_OLLAMA_MODEL),
            device=os.getenv("VLM_DEVICE", "auto"),
            quantization=os.getenv("VLM_QUANTIZATION") or None,
            max_tokens=int(os.getenv("VLM_MAX_TOKENS", "512")),
            temperature=float(os.getenv("VLM_TEMPERATURE", "0")),
        )

    def validate(self) -> None:
        if self.backend not in {"ollama", "transformers", "mock"}:
            raise ValueError("VLM_BACKEND must be one of: ollama, transformers, mock")
        if self.max_tokens <= 0:
            raise ValueError("VLM_MAX_TOKENS must be positive")
        if self.adapter_path:
            path = Path(self.adapter_path).expanduser()
            if not path.is_dir():
                raise FileNotFoundError(f"Configured LoRA adapter does not exist: {path}")
            if self.backend == "ollama":
                raise ValueError(
                    "A PEFT LoRA adapter cannot be loaded by the Ollama backend directly. "
                    "Set VLM_BACKEND=transformers or merge/package the adapter using a "
                    "backend-supported model conversion workflow."
                )
            if self.backend == "mock":
                raise ValueError("VLM_BACKEND=mock cannot load or represent a trained adapter.")
            adapter_config = path / "adapter_config.json"
            if not adapter_config.is_file():
                raise ValueError(f"Adapter directory lacks adapter_config.json: {path}")


def verify_adapter_compatibility(base_model: str, adapter_path: str | Path) -> None:
    """Reject known base-model mismatches using PEFT's saved adapter metadata."""
    import json

    adapter_path = Path(adapter_path).expanduser()
    config_path = adapter_path / "adapter_config.json"
    if not config_path.is_file():
        raise FileNotFoundError(f"LoRA adapter metadata not found: {config_path}")
    config = json.loads(config_path.read_text(encoding="utf-8"))
    adapter_base = config.get("base_model_name_or_path")
    if not adapter_base:
        raise ValueError(
            f"Cannot verify adapter compatibility: {config_path} has no "
            "base_model_name_or_path. Re-export the adapter with PEFT metadata."
        )
    if adapter_base.rstrip("/").casefold() != base_model.rstrip("/").casefold():
        raise ValueError(
            "Model compatibility error:\n\n"
            f"Configured base model:\n{base_model}\n\n"
            f"Configured LoRA adapter was trained for:\n{adapter_base}\n\n"
            "These model identities do not match. Train/load an adapter for the "
            "configured base model; a 3B adapter cannot be attached to the 7B model."
        )
