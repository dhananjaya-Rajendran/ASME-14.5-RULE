"""Structured drawing models."""
