"""Extract explicit hole callout text; geometry and feature links remain unassigned."""
import re

from gdt_validator.models.drawing_ir import FeaturePattern, HoleFeature

DIAMETER = r"(?:\u00d8|\u2300|\u2205|DIA\s*)"
MULTIPLY = r"(?:x|\u00d7)"


def extract_hole_callouts(text_blocks: list[dict], page: int = 1) -> tuple[list[HoleFeature], list[FeaturePattern]]:
    holes, patterns = [], []
    for index, block in enumerate(text_blocks):
        text = str(block.get("text", "")).strip()
        dia = (re.search(r"(?i)\bDIA\s*(\d+(?:[.,]\d+)?)", text)
               or re.search(rf"{DIAMETER}\s*(\d+(?:[.,]\d+)?)", text))
        thread = re.search(rf"(?i)\bM\s*\d+(?:[.,]\d+)?(?:\s*{MULTIPLY}\s*\d+(?:[.,]\d+)?)?", text)
        if not dia and not thread:
            continue
        explicit_hole_cue = bool(thread or re.search(
            r"(?i)\bTHRU\b|THROUGH|DEPTH|DEEP|COUNTERBORE|COUNTERSINK|\d+\s*[xX]\s*", text))
        if not explicit_hole_cue:
            continue
        quantity_match = (re.search(r"(?i)(\d+)\s*[xX]\s*(?=DIA\b|M\b)", text)
                          or re.search(rf"(?i)(\d+)\s*{MULTIPLY}\s*(?={DIAMETER}|M)", text))
        quantity = int(quantity_match.group(1)) if quantity_match else 1
        depth_match = re.search(r"(?i)(?:DEPTH|DEEP)\s*(\d+(?:[.,]\d+)?)", text)
        termination = "THRU" if re.search(r"(?i)\bTHRU\b|THROUGH", text) else "UNKNOWN"
        hole_id = f"hole_p{page}_{index:04d}"
        confidence = float(block.get("confidence", 0.8))
        holes.append(HoleFeature(
            id=hole_id, diameter=float(dia.group(1).replace(",", ".")) if dia else None,
            quantity=quantity, depth=float(depth_match.group(1).replace(",", ".")) if depth_match else None,
            termination=termination, thread=thread.group(0) if thread else None,
            page=page, bbox=list(block.get("bbox") or [0, 0, 0, 0]), source_text=text,
            confidence=max(0.0, min(1.0, confidence))))
        if quantity > 1:
            pcd_match = re.search(rf"(?i)(?:PCD|{DIAMETER}BC|BOLT CIRCLE)\s*(\d+(?:[.,]\d+)?)", text)
            angle = re.search(r"(?i)(\d+(?:[.,]\d+)?)\s*\u00b0\s*(?:EQ|EQUALLY)", text)
            patterns.append(FeaturePattern(
                id=f"pattern_{hole_id}", type="CIRCULAR" if pcd_match else "UNKNOWN",
                quantity=quantity,
                pcd=float(pcd_match.group(1).replace(",", ".")) if pcd_match else None,
                angular_spacing=float(angle.group(1).replace(",", ".")) if angle else None,
                evidence={"source": "pdf_text", "page": page,
                          "bbox": list(block.get("bbox") or [0, 0, 0, 0]),
                          "source_text": text, "confidence": confidence}))
    return holes, patterns
