"""Extract explicitly labeled title-block values without guessing unlabeled cells."""
import re

from gdt_validator.models.drawing_ir import DrawingMetadata, Evidence

LABELS = {
    "drawing_number": r"(?:DRAWING|DWG)\s*(?:NO|NUMBER|#)\s*[:#]?\s*([^\n|]+?)(?=\s+REV(?:ISION)?\b|\s+SHEET\b|$)",
    "part_number": r"(?:PART|ITEM)\s*(?:NO|NUMBER|#)\s*[:#]?\s*([^\n|]+?)(?=\s+REV(?:ISION)?\b|\s+SHEET\b|$)",
    "title": r"(?:TITLE|PART NAME|DESCRIPTION)\s*[:=]?\s*([^\n|]+)",
    "revision": r"(?:REV(?:ISION)?)\s*[:=]?\s*([A-Z0-9._-]+)",
    "scale": r"SCALE\s*[:=]?\s*([0-9:.]+)",
    "drawing_standard": r"(?:STANDARD|STD)\s*[:=]?\s*((?:ASME|ISO|ANSI)[^\n|]*)",
}


def extract_title_block(text_blocks: list[dict], page: int = 1) -> DrawingMetadata:
    text = "\n".join(str(block.get("text", "")) for block in text_blocks)
    values = {}
    evidence = []
    for field, pattern in LABELS.items():
        match = re.search(pattern, text, re.I)
        if match:
            value = match.group(1).strip().strip(" :;|")
            if value:
                values[field] = value
                evidence.append(Evidence(source="pdf_text", page=page, source_text=match.group(0),
                                         confidence=0.82))
    sheet = re.search(r"(?i)SHEET\s*(\d+)\s*(?:OF|/)\s*(\d+)", text)
    if sheet:
        values.update(sheet_number=int(sheet.group(1)), sheet_count=int(sheet.group(2)))
        evidence.append(Evidence(source="pdf_text", page=page, source_text=sheet.group(0),
                                 confidence=0.85))
    units = re.search(r"(?i)\b(MM|MILLIMETERS?|INCHES|IN)\b", text)
    if units:
        token = units.group(1).upper()
        values["units"] = "MM" if token.startswith("M") else "IN"
        evidence.append(Evidence(source="pdf_text", page=page, source_text=units.group(0),
                                 confidence=0.75))
    return DrawingMetadata(**values, evidence=evidence)
