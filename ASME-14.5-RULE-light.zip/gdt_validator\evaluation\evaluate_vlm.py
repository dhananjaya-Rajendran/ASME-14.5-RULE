"""Baseline Qwen extraction benchmark over manually reviewed JSONL labels.

No adapter is loaded here: this command measures the configured base model.
An empty dataset writes a NOT RUN report and never invokes a model.
"""
import argparse
import json
from pathlib import Path
from statistics import mean

from gdt_validator.vision.extraction_prompt import DRAWING_EXTRACTION_PROMPT
from gdt_validator.vision.model_config import ModelConfig
from gdt_validator.vision.vlm_client import create_vlm_client

REPORT_DIR = Path(__file__).resolve().parents[1] / "reports"
THRESHOLDS_PATH = Path(__file__).resolve().parent / "thresholds.json"

SCALAR_FIELDS = (
    "tolerance_value", "diameter_zone", "material_condition",
    "associated_feature_type", "is_feature_of_size", "has_size_tolerance_on_feature",
)
LIST_FIELDS = ("datums", "dimensions", "hole_callouts", "drawing_notes", "features")
ERROR_FIELD_TAXONOMY = {
    "characteristic_symbol": "WRONG_SYMBOL",
    "tolerance_value": "WRONG_TOLERANCE",
    "material_condition": "WRONG_MODIFIER",
    "datums": "WRONG_DATUM",
    "associated_feature_type": "WRONG_FEATURE_ASSOCIATION",
    "dimensions": "WRONG_DIMENSION",
}


def load_rows(path: Path) -> list[dict]:
    rows = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        item = json.loads(line)
        if not isinstance(item, dict) or not isinstance(item.get("expected"), dict):
            raise ValueError(f"Line {number}: expected an object with a manually reviewed expected object.")
        if item.get("label_status") != "EXPERT_VERIFIED":
            raise ValueError(f"Line {number}: labels must be marked EXPERT_VERIFIED before scoring.")
        image = Path(item["image"])
        if not image.is_absolute():
            image = path.parent / image
        if not image.is_file():
            raise FileNotFoundError(f"Line {number}: image missing: {image}")
        item["_image"] = image
        rows.append(item)
    return rows


def _canonical(value):
    if isinstance(value, dict):
        return json.dumps(value, sort_keys=True, ensure_ascii=False)
    if isinstance(value, list):
        return tuple(_canonical(item) for item in value)
    return value


def _f1(tp: int, fp: int, fn: int) -> dict:
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    return {"precision": precision, "recall": recall,
            "f1": 2 * precision * recall / (precision + recall) if precision + recall else 0.0,
            "true_positive": tp, "false_positive": fp, "false_negative": fn}


def _valid_extraction_response(value: dict) -> bool:
    required = {"characteristic_symbol", "tolerance_value", "diameter_zone",
                "material_condition", "datums", "associated_feature_type",
                "is_feature_of_size", "has_size_tolerance_on_feature",
                "confidence", "review_required"}
    if not required.issubset(value):
        return False
    tolerance, confidence = value["tolerance_value"], value["confidence"]
    return (
        isinstance(value["characteristic_symbol"], str)
        and (tolerance is None or isinstance(tolerance, (int, float)) and not isinstance(tolerance, bool))
        and isinstance(value["diameter_zone"], bool)
        and value["material_condition"] in {None, "RFS", "MMC", "LMC"}
        and isinstance(value["datums"], list)
        and all(isinstance(datum, str) or isinstance(datum, dict) and
                isinstance(datum.get("datum_letter"), str) for datum in value["datums"])
        and value["associated_feature_type"] in {"hole", "shaft", "planar_surface", "unknown"}
        and isinstance(value["is_feature_of_size"], (bool, type(None)))
        and isinstance(value["has_size_tolerance_on_feature"], (bool, type(None)))
        and isinstance(confidence, (int, float)) and not isinstance(confidence, bool)
        and 0 <= confidence <= 1
        and isinstance(value["review_required"], bool)
    )


def evaluate(client, rows: list[dict]) -> dict:
    if not rows:
        return {"status": "NOT_RUN", "reason": "No expert-verified labeled examples."}
    json_valid = 0
    field_correct, field_total = {}, {}
    fcf_tp = fcf_fp = fcf_fn = 0
    datum_tp = datum_fp = datum_fn = 0
    dimension_tp = dimension_fp = dimension_fn = 0
    bbox_ious, errors = [], {}
    outputs = []
    for row in rows:
        try:
            predicted = client.analyze_drawing(str(row["_image"]),
                row.get("instruction") or DRAWING_EXTRACTION_PROMPT)
            if not isinstance(predicted, dict):
                raise ValueError("VLM response was not an object")
            if _valid_extraction_response(predicted):
                json_valid += 1
            else:
                errors["JSON_SCHEMA_ERROR"] = errors.get("JSON_SCHEMA_ERROR", 0) + 1
        except (ValueError, RuntimeError, OSError, KeyError) as exc:
            predicted = {}
            errors["JSON_SCHEMA_ERROR"] = errors.get("JSON_SCHEMA_ERROR", 0) + 1
        outputs.append(predicted)
        expected = row["expected"]
        expected_fcf = bool(expected.get("feature_control_frame", expected.get("characteristic_symbol")))
        predicted_fcf = bool(predicted.get("characteristic_symbol") not in (None, "", "unknown"))
        fcf_tp += int(expected_fcf and predicted_fcf)
        fcf_fp += int(not expected_fcf and predicted_fcf)
        fcf_fn += int(expected_fcf and not predicted_fcf)
        if expected_fcf and not predicted_fcf:
            errors["MISSING_FCF"] = errors.get("MISSING_FCF", 0) + 1
        if predicted_fcf and not expected_fcf:
            errors["EXTRA_FCF"] = errors.get("EXTRA_FCF", 0) + 1
        for field in SCALAR_FIELDS + ("characteristic_symbol", "tolerance_zone", "feature_id"):
            if field not in expected:
                continue
            field_total[field] = field_total.get(field, 0) + 1
            matches = _canonical(predicted.get(field)) == _canonical(expected[field])
            field_correct[field] = field_correct.get(field, 0) + int(matches)
            if not matches:
                category = ERROR_FIELD_TAXONOMY.get(field)
                if category:
                    errors[category] = errors.get(category, 0) + 1
        for field, counts in (("datums", [datum_tp, datum_fp, datum_fn]),
                              ("dimensions", [dimension_tp, dimension_fp, dimension_fn])):
            if field not in expected:
                continue
            gold = {_canonical(value) for value in expected[field]}
            guess = {_canonical(value) for value in predicted.get(field, [])} if isinstance(predicted.get(field, []), list) else set()
            tp, fp, fn = len(gold & guess), len(guess - gold), len(gold - guess)
            if field == "datums":
                datum_tp += tp; datum_fp += fp; datum_fn += fn
            else:
                dimension_tp += tp; dimension_fp += fp; dimension_fn += fn
            if fn:
                key = "WRONG_DATUM" if field == "datums" else "WRONG_DIMENSION"
                errors[key] = errors.get(key, 0) + fn
        if isinstance(expected.get("bbox"), list) and isinstance(predicted.get("bbox"), list):
            bbox_ious.append(_bbox_iou(predicted["bbox"], expected["bbox"]))
    accuracies = {field: field_correct.get(field, 0) / count
                  for field, count in field_total.items() if count}
    return {
        "status": "MEASURED", "examples": len(rows),
        "drawings": len({row.get("drawing_id") for row in rows if row.get("drawing_id")}),
        "fcf_detection": _f1(fcf_tp, fcf_fp, fcf_fn),
        "datum_detection": _f1(datum_tp, datum_fp, datum_fn),
        "dimension_detection": _f1(dimension_tp, dimension_fp, dimension_fn),
        "field_accuracy": accuracies,
        "mean_field_accuracy": mean(accuracies.values()) if accuracies else None,
        "feature_association_accuracy": accuracies.get("feature_id"),
        "modifier_accuracy": accuracies.get("material_condition"),
        "json_validity": json_valid / len(rows),
        "mean_bbox_iou": mean(bbox_ious) if bbox_ious else None,
        "error_taxonomy": errors,
        "per_example": [{"drawing_id": row.get("drawing_id"), "image": str(row["_image"]),
                         "expected": row["expected"], "predicted": output}
                        for row, output in zip(rows, outputs)],
    }


def _bbox_iou(a: list, b: list) -> float:
    if len(a) != 4 or len(b) != 4:
        return 0.0
    x0, y0 = max(a[0], b[0]), max(a[1], b[1])
    x1, y1 = min(a[2], b[2]), min(a[3], b[3])
    intersection = max(0, x1 - x0) * max(0, y1 - y0)
    area_a = max(0, a[2] - a[0]) * max(0, a[3] - a[1])
    area_b = max(0, b[2] - b[0]) * max(0, b[3] - b[1])
    union = area_a + area_b - intersection
    return intersection / union if union else 0.0


def render_report(result: dict, config: ModelConfig, dataset: Path) -> str:
    model = config.ollama_model if config.backend == "ollama" else config.production_model
    thresholds = json.loads(THRESHOLDS_PATH.read_text(encoding="utf-8"))
    if result.get("status") != "MEASURED":
        metrics = (f"Benchmark status: {result.get('status', 'NOT RUN')}\n\n"
                   f"{result.get('reason', 'No expert-verified image labels were available.')}\n\n"
                   "Dataset counts: drawings=0; FCFs=NOT MEASURED; datums=NOT MEASURED; "
                   "dimensions=NOT MEASURED; validation cases=0.\n\n"
                   "FCF/datum/dimension precision, recall, F1; modifier accuracy; feature "
                   "association accuracy; JSON validity; rule accuracy; and end-to-end "
                   "accuracy: NOT MEASURED. No model accuracy claim was made.")
    else:
        fcf = result["fcf_detection"]
        datum = result["datum_detection"]
        dimension = result["dimension_detection"]
        metrics = (f"Unique drawings: {result['drawings']}\n\nLabeled examples: {result['examples']}\n\n"
            f"FCF precision / recall / F1: {fcf['precision']:.4f} / {fcf['recall']:.4f} / {fcf['f1']:.4f}\n"
            f"Datum precision / recall / F1: {datum['precision']:.4f} / {datum['recall']:.4f} / {datum['f1']:.4f}\n"
            f"Dimension precision / recall / F1: {dimension['precision']:.4f} / {dimension['recall']:.4f} / {dimension['f1']:.4f}\n"
            f"JSON validity: {result['json_validity']:.4f}\n"
            f"Modifier accuracy: {result['modifier_accuracy']}\n"
            f"Feature association accuracy: {result['feature_association_accuracy']}\n"
            f"Mean bounding-box IoU: {result['mean_bbox_iou']}\n"
            f"Error taxonomy: {json.dumps(result['error_taxonomy'], sort_keys=True)}")
    return ("# Qwen2.5-VL baseline evaluation\n\n"
        f"Model: `{model}`\n\nModel version: configured model identifier; immutable artifact digest not recorded.\n\n"
        f"Inference backend: `{config.backend}`\n\n"
        f"Device: `{config.device}`; quantization: `{config.quantization or 'none/configured by backend'}`; "
        "hardware: `not recorded by evaluator`\n\n"
        f"Dataset: `{dataset}`\n\n{metrics}\n\n"
        "Ground-truth policy: only rows marked `EXPERT_VERIFIED` are scored. "
        "Mock-mode runs are software tests and are not model benchmark results.\n\n"
        "Rule validation accuracy: NOT MEASURED (no expert-verified structured validation set).\n\n"
        "PASS / FAIL / INSUFFICIENT_INFORMATION accuracy: NOT MEASURED.\n\n"
        "End-to-end accuracy: NOT MEASURED.\n\n"
        f"Proposed extraction targets (owner approval required): `{json.dumps(thresholds['targets'], sort_keys=True)}`. "
        "These are engineering extraction quality targets, not compliance criteria.\n\n"
        "LoRA recommendation: DEFERRED until a real baseline and its failure modes are measured.\n")


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate configured base Qwen2.5-VL without an adapter.")
    parser.add_argument("--dataset", type=Path,
        default=Path(__file__).resolve().parents[1] / "datasets" / "golden" / "extraction" / "benchmark.jsonl")
    parser.add_argument("--backend", choices=["ollama", "transformers", "mock"], default=None)
    parser.add_argument("--model", default=None, help="Model override recorded in the report.")
    parser.add_argument("--device", default=None)
    parser.add_argument("--output-json", type=Path, default=REPORT_DIR / "qwen25vl_baseline.json")
    parser.add_argument("--output-report", type=Path, default=REPORT_DIR / "baseline_qwen25vl_report.md")
    args = parser.parse_args()
    config = ModelConfig.from_env()
    updates = {}
    if args.backend:
        updates["backend"] = args.backend
    if args.device:
        updates["device"] = args.device
    if args.model:
        updates["ollama_model" if (args.backend or config.backend) == "ollama" else "production_model"] = args.model
    if updates:
        config = ModelConfig(**{**config.__dict__, **updates})
    config.validate()
    rows = load_rows(args.dataset) if args.dataset.is_file() else []
    if config.backend == "mock":
        result = {"status": "NOT_A_MODEL_BENCHMARK",
                  "reason": "Mock mode validates software paths only and cannot measure model accuracy.",
                  "examples": 0}
    elif rows:
        result = evaluate(create_vlm_client(config), rows)
    else:
        result = {"status": "NOT_RUN", "reason": "Benchmark dataset missing or contains no expert-verified examples.",
                  "examples": 0}
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    args.output_report.parent.mkdir(parents=True, exist_ok=True)
    args.output_json.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    args.output_report.write_text(render_report(result, config, args.dataset), encoding="utf-8")
    print(json.dumps({"status": result["status"], "model": config.ollama_model if config.backend == "ollama" else config.production_model,
                      "json": str(args.output_json), "report": str(args.output_report)}, indent=2))


if __name__ == "__main__":
    main()
