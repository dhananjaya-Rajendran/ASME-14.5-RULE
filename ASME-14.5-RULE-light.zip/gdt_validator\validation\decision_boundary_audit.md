# Deterministic validation and RAG boundary audit

## Audited paths

| Location | Before | Current boundary |
|---|---|---|
| `main.py` | Called RAG enrichment inline on rule-engine violations. | Calls Python rule engine first, freezes each outcome as a `RuleDecision`, then requests separate explanation records. |
| `validation/asme_rule_engine.py` | Produced findings from explicit structured fields. | Still does deterministic checks. Registry entries not marked `EXPERT_VERIFIED` are downgraded to `REVIEW_REQUIRED`. |
| `validation/rag_explainer.py` | Mutated `ValidationViolation` with retrieved context/remediation. | Accepts `RuleDecision`; returns `RuleExplanation`; has no API to edit or return a decision. |
| `knowledge_base.py` | Retrieval could query the configured local archive/index without an edition argument. | Retrieval checks completed archive edition and Chroma collection edition against the requested edition. Mismatch returns no passages. |
| `vision/extraction_prompt.py` | Extraction-only prompt. | Explicitly prohibits compliance judgment and invented unreadable data. |
| `vision/vlm_client.py` | Extracts ROI data; optional narrative helper only summarized fixed violations. | VLM remains extraction-only in the validation pipeline. The legacy narrative helper is not called to make or change decisions. |
| `reporting/report_builder.py` | Mixed retrieved context into each mutable finding object. | Shows deterministic findings and separate explanation/citation records. |

Searches covered RAG, retriever/vector/embedding, Chroma, knowledge, LLM/provider names, ASME, validation/rules, compliance, prompts, and PASS/FAIL references under the application package. No prompt requests a compliance decision. The sole former RAG call site was `main.py`; no LLM output was read to set `validation_status`.

## Current constraints and safeguards

- `RuleDecision` is frozen and RAG explanations are separate typed objects.
- Reference lookup is restricted to the exact configured edition. The current approved local archive path is specifically Y14.5M-1994; an empty, incomplete, or mismatched archive yields `INSUFFICIENT_REFERENCE_EVIDENCE`.
- Section citations are emitted only when retrieval returned section metadata matching the rule's reference hint. Source identifiers include the archive source name and page; no missing section is fabricated.
- No current rule has independent expert verification in this checkout. Registry entries are `UNDER_REVIEW`; findings are therefore `REVIEW_REQUIRED`, not authoritative PASS/FAIL.
- The engine is still a limited subset, extraction is incomplete, and the repository has no expert-reviewed golden dataset. The system does not claim complete Y14.5 compliance.

## Remaining acceptance work

1. An authorized GD&T expert must verify each rule against the licensed active edition and approve changes to `verification_status`.
2. Add expert-labeled positive, negative, boundary, missing-data, modifier, datum, and unit cases; only then can the golden deterministic evaluation be meaningful.
3. Add separate RAG retrieval/citation/explanation evaluation fixtures and metrics.
4. Complete DrawingIR normalization and feature association before expanding deterministic rule coverage.

The checks implemented here close the architectural decision boundary, not every acceptance item in the pasted specification.
